function tryCatch(fn) {
    try {
        const result = fn();
        return { error: null, result };
    } catch (err) {
        return { error: err, result: null };
    }
}

export default tryCatch