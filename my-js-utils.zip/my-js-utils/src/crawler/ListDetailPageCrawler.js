import CurlHelper from "../curl/CurlHelper"
import AbstractCrawler from "./AbstractCrawler"
import TempermonkeyHttpClient from "./http/TempermonkeyHttpClient"
import ChromeExtensionHttpClient from "./http/ChromeExtensionHttpClient"
import EnvironmentHelper from "../common/EnvironmentHelper"

/**
 * 可以处理以下类型的页面
 * 1.列表-详情页面
 * 2.单个详情页面
 */
class ListDetailPageCrawler extends AbstractCrawler {
    /**
     * 请求页面、结果字段提取的配置
     */
    flowDefinition
    /**
     * 发送请求函数，接收一个config对象(axios格式)，返回一个Promise
     */
    abstractHttpClient

    constructor(flowDefinition) {
        super()
        if (flowDefinition.listPage) {
            flowDefinition.listPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.listPage)
        }
        if (flowDefinition.detailPage) {
            flowDefinition.detailPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.detailPage)
        }
        this.flowDefinition = flowDefinition
        EnvironmentHelper.detectEnvironment({
            tampermonkey: () => {
                this.abstractHttpClient = new TempermonkeyHttpClient()
            },
            chromeExtension: () => {
                this.abstractHttpClient = new ChromeExtensionHttpClient()
            },
            other: () => {
                throw new Error("未知的运行环境")
            }
        })
    }

    async callFlow(config) {
        config = !config ? { pageNum: 1 } : config
        config.pageNum = !config.pageNum ? 1 : config.pageNum
        const { pageNum } = config
        const flowInst = JSON.parse(JSON.stringify(this.flowDefinition))
        const { listPage, detailPage } = flowInst

        // 存储某一页列表页面和这一页所有详情的信息
        const context = { pageNum }

        // 请求列表页面
        if (listPage) {
            if (listPage.url) {
                listPage.url = this.doEval("`" + this.flowDefinition.listPage.url + "`", context)
            }
            if (listPage.curl) {
                listPage.curl = this.doEval("`" + this.flowDefinition.listPage.curl + "`", context)
            }

            // 提取列表页面信息
            console.log(`开始请求第${pageNum}页列表页面`)
            const listPageData = await this.sendRequest(listPage)
            const listPageInfo = this.handleFields(listPageData, listPage.fields)
            context.listPage = listPageInfo
        }

        // 循环列表页面中的每一个详情页
        if (detailPage) {
            context.detailPage = []
            const isListDetailPage = detailPage.collection != null // 没有配置collection，则认为是单个详情页
            let list = isListDetailPage ? this.doEval(detailPage.collection, context) : [context]
            list = this.jqueryListToArray(list)
            const itemKey = detailPage.item || "item"
            const detailPageInfoList = context.detailPage
            const detailPagePromiseList = list.map(async item => {
                // 获取详情页地址
                const detailEvalCtx = Object.assign({}, context)
                detailEvalCtx[itemKey] = item
                if (this.flowDefinition.detailPage.url) {
                    detailPage.url = this.doEval("`" + this.flowDefinition.detailPage.url + "`", detailEvalCtx)
                }
                if (this.flowDefinition.detailPage.curl) {
                    detailPage.curl = this.doEval("`" + this.flowDefinition.detailPage.curl + "`", detailEvalCtx)
                }
                // 请求详情页面
                const detailPageData = await this.sendRequest(detailPage)
                const detailPageInfo = this.handleFields(detailPageData, detailPage.fields)
                detailPageInfoList.push(detailPageInfo)
            })
            
            console.log(`第${pageNum}页详情页面已提交到异步任务执行`)
            Promise.all(detailPagePromiseList).then(() => {
                console.log(`第${pageNum}详情页面抓取完成`)
                context.detailPage = isListDetailPage ? context.detailPage : context.detailPage[0]
                config.onPageCompleted && config.onPageCompleted(context)
            })
        }

        // 抓取下一页
        if (listPage) {
            const hasNextPage = context.listPage.totalPage && pageNum < context.listPage.totalPage || context.listPage.hasNextPage
            if (hasNextPage && (config.maxPageNum && pageNum < config.maxPageNum)) {
                config.pageNum++
                this.callFlow(config)
            }
        }
    }

    async sendRequest(config) {
        const requestInfo = CurlHelper.parse(config.curl)
        if (requestInfo) {
            if (requestInfo.params) {
                config.url = requestInfo.url + "?" + new URLSearchParams(requestInfo.params).toString()
            } else {
                config.url = requestInfo.url
            }
            config.method = requestInfo.method
            config.headers = requestInfo.headers || {}
            config.data = requestInfo.body
        }
        return this.abstractHttpClient.sendRequest(config)
    }

    jqueryListToArray(list) {
        return list.jquery ? list.toArray() : list
    }
}

export default ListDetailPageCrawler