import AbstractHttpClient from "./AbstractHttpClient"

class TempermonkeyHttpClient extends AbstractHttpClient {
    constructor() {
        super()
        this.domParser = new DOMParser()
    }

    async sendRequest(config) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: config.method,
                url: config.url,
                headers: config.headers,
                data: config.data,
                onload: response => {
                    if (response.status === 200) {
                        // 获取某个特定的响应头，比如 "Content-Type"
                        const contentTypeLine = response.responseHeaders.match(/Content-Type:\s*(.*)\s*/i)
                        if (contentTypeLine) {
                            const contentType = contentTypeLine[1]
                            if (contentType.indexOf("json") >= 0) {
                                resolve(JSON.parse(response.responseText))
                                return
                            }
                        }
                        const doc = this.domParser.parseFromString(response.responseText, 'text/html')
                        resolve(doc)
                    } else {
                        reject(response)
                    }
                },
                onerror: err => {
                    reject(err)
                }
            })
        })
    }
}

export default TempermonkeyHttpClient