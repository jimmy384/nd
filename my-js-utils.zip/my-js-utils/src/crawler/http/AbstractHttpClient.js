class AbstractHttpClient {
    constructor() {
    }

    async sendRequest(config) {
        return new Promise((resolve, reject) => {
            reject("Not implemented")
        })
    }
}

export default AbstractHttpClient