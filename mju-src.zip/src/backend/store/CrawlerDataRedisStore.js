import Redis from 'ioredis'
import CrawlerDataStore from './CrawlerDataStore.js'

/**
 * 爬虫数据存储实现 - Redis
 */
export default class CrawlerDataRedisStore extends CrawlerDataStore {
    constructor(dataType) {
        super(dataType)
        // 初始化 Redis 客户端
        this.redisClient = new Redis({
            host: '127.0.0.1',
            port: 6379,
            db: 0
        })

        // Redis 键命名
        this.dataKey = `crawler:${this.dataType}:data` // 用于存储爬取的数据（Hash 结构）
        this.urlKey = `crawler:${this.dataType}:urls` // 用于存储已爬取的URL（Set 结构）
        return this.constructorInit()
    }

    //@Override
    async hasCrawled(url) {
        // 检查 URL 是否存在于 Redis 的 Set 或本地临时缓存
        const exists = await this.redisClient.sismember(this.urlKey, url)
        return exists || this.incrUrlSet.has(url)
    }

    //@Override
    async flushIncrDataList(newDataList) {
        // 将增量数据存储到 Redis 的 Hash 中
        const pipeline = this.redisClient.pipeline()
        newDataList.forEach(data => {
            if (data.id) {
                pipeline.hset(this.dataKey, data.id, JSON.stringify(data))
            } else {
                console.warn('数据缺少 id 属性，跳过存储:', data)
            }
        })
        await pipeline.exec()
    }

    //@Override
    async flushIncrUrl(incrUrlSet) {
        // 将增量 URL 存储到 Redis 的 Set 中
        if (incrUrlSet.size > 0) {
            await this.redisClient.sadd(this.urlKey, ...Array.from(incrUrlSet))
        }
    }

    //@Override
    async init() {
    }

    //@Override
    async getAllDataList() {
        const allDataMap = await this.getAllDataMap()
        return Array.from(allDataMap.values()).map(json => JSON.parse(json))
    }

    //@Override
    async getAllDataMap() {
        const allDataMap = await this.redisClient.hgetall(this.dataKey)
        const map = new Map()
        Object.entries(allDataMap).forEach(([key, value]) => {
            map.set(key, value)
        })
        return map
    }

}