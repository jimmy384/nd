import EventEmitter from "events"

/**
 * 爬虫数据存储接口
 */
export default class CrawlerDataStore {
    constructor(dataType) {
        this.dataType = dataType
        /**
         * 内存中临时存储增量数据
         * {
         *     "dataType": "数据类型",
         *     "url": "数据从哪个地址爬的",
         *     "data": {
         *         "id": "唯一标识，实在没有取url",
         *         其他字段，爬取到的数据
         *     }
         * }
         */
        this.incrDataList = []
        /**
         * 增量数据对应的url，避免重复爬取
         */
        this.incrUrlSet = new Set()
        /**
         * incrDataList增量数据达到batchSize后，开始同步到存储中
         */
        this.batchSize = 20
        /**
         * 事件
         */
        this.eventEmitter = new EventEmitter()
    }

    constructorInit() {
        return new Promise((resolve, reject) => {
            this.init().then(() => {
                resolve(this)
            }).catch(err => {
                reject(err)
            })
        })
    }

    /**
     * 添加增量数据
     */
    async addIncrData(incrData) {
        const incrDataList = Array.isArray(incrData) ? incrData : [incrData]
        for (const incrData of incrDataList) {
            const { url } = incrData
            if (await this.hasCrawled(url)) {
                continue
            }
            this.incrDataList.push(incrData)
            this.incrUrlSet.add(incrData.url)
        }
        if (this.incrDataList.length >= this.batchSize) {
            this.flush()
        }
    }

    /**
     * 判断url是否已经被爬取过
     */
    async hasCrawled(url) {
        throw new Error('Not implemented')
    }

    /**
     * 过滤出未被爬取过的url
     */
    async filterUncrawled(urlList) {
        const promiseList = urlList.map(url => this.hasCrawled(url))
        return Promise.all(promiseList).then(hasCrawledList => {
            return urlList.filter((url, index) => !hasCrawledList[index])
        })
    }

    /**
     * 内存中的增量数据同步到存储中
     */
    async flush() {
        // 要保存的新数据列表
        const newDataList = this.incrDataList.map(incrData => incrData.data)
        await this.flushIncrDataList(newDataList)

        // 把增量数据的url保存起来，避免下次重复爬取
        await this.flushIncrUrl(this.incrUrlSet)

        // 发送flush事件
        this.eventEmitter.emit('flush', {
            newDataList,
            incrUrlSet: this.incrUrlSet
        })

        // 增量数据消费完成，清空
        this.incrDataList = []
        this.incrUrlSet.clear()
    }

    /**
     * 增量数据同步到存储中
     */
    async flushIncrDataList(newDataList) {
        throw new Error('Not implemented')
    }

    /**
     * 增量数据对应的url同步到存储中
     */
    async flushIncrUrl(incrUrlSet) {
        throw new Error('Not implemented')
    }

    /**
     * 初始化逻辑
     */
    async init() {

    }

    /**
     * 获取所有数据(List)
     */
    async getAllDataList() {
        throw new Error('Not implemented')
    }

    /**
     * 获取所有数据(Map)
     */
    async getAllDataMap() {
        throw new Error('Not implemented')
    }

    on(event, listener) {
        this.eventEmitter.on(event, listener)
    }

}