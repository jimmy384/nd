import fs from 'fs'
import CrawlerDataStore from './CrawlerDataStore.js'

/**
 * 爬虫数据存储实现 - 文件系统
 */
export default class CrawlerDataFileStore extends CrawlerDataStore {
    constructor(dataType) {
        super(dataType)
        /**
         * 记录所有爬取过的url，初始化时从文件中读取
         */
        this.fullUrlSet = new Set()
        this.basePath = "./crawlerData"
        this.dataFilePath = `${this.basePath}/${this.dataType}.json`
        this.crawledUrlFilePath = `${this.basePath}/${this.dataType}_crawled.txt`
        return this.constructorInit()
    }

    // @Override
    async hasCrawled(url) {
        return this.fullUrlSet.has(url) || this.incrUrlSet.has(url)
    }
    
    // @Override
    async flushIncrDataList(newDataList) {
        // 读取以前文件的全部旧数据
        const oldDataList = await this.getAllDataList()
        // 新数据追加到旧数据后面
        oldDataList.push(...newDataList)
        // 保存全部数据
        fs.writeFileSync(this.dataFilePath, JSON.stringify(oldDataList))
    }

    // @Override
    async flushIncrUrl(incrUrlSet) {
        fs.appendFileSync(this.crawledUrlFilePath, Array.from(incrUrlSet).join('\n') + '\n')
        for (const incrUrl of incrUrlSet) {
            this.fullUrlSet.add(incrUrl)
        }
    }

    // @Override
    async init() {
        // 从文件中读取所有爬取过的url
        await this.readFullUrlSet()
    }

    async readFullUrlSet() {
        let set = new Set()
        try {
            set = new Set(fs.readFileSync(this.crawledUrlFilePath, 'utf-8').split('\n'))
        } catch (e) {
            console.warn(`读取到已爬取过的url失败，当作空文件处理, ${this.crawledUrlFilePath}`)
        }
        console.log(`读取到已爬取过的url数量: ${set.size}`)
        this.fullUrlSet = set
    }

    // @Override
    async getAllDataList() {
        let exists = fs.existsSync(this.basePath)
        if (!exists) {
            fs.mkdirSync(this.basePath)
        }
        let oldDataList = []
        exists = fs.existsSync(this.dataFilePath)
        if (exists) {
            const jsonStr = fs.readFileSync(this.dataFilePath, 'utf-8')
            oldDataList = JSON.parse(jsonStr)
        }
        return oldDataList
    }

    // @Override
    async getAllDataMap() {
        const dataList = await this.getAllDataList()
        const map = new Map()
        for (const data of dataList) {
            map.set(data.id, data)
        }
        return map
    }

}