import Index from './Index.js'
import fs from 'fs'

export default class FileIndex extends Index {
    constructor(config, store) {
        super(config, store)
        this.dataType = store.dataType
        this.basePath = "./crawerData"
        this.indexFilePath = `${this.basePath}/${this.dataType}_index.json`
        this.unindexFilePath = `${this.basePath}/${this.dataType}_unindex.txt`
        return this.constructorInit()
    }

    // 记录索引没有持久化的数据
    // @Override
    async flushUnindexUrl(incrUrlSet) {
        if (incrUrlSet.size > 0) {
            let unindexUrlList = Array.from(incrUrlSet)
            fs.writeFileSync(this.unindexFilePath, unindexUrlList.join('\n') + "\n")
        }
    }

    // 读取构建好的索引，返回构建好的索引
    // @Override
    async indexMetaReadLogic() {
        if (fs.existsSync(this.indexFilePath)) {
            return JSON.parse(fs.readFileSync(this.indexFilePath, 'utf-8'))
        }
        return null
    }

    // 读取未建立好索引数据的url
    // @Override
    async getUnindexUrlSetLogic() {
        // 从文件中读取未被索引的url
        let unindexSet = new Set()
        try {
            unindexSet= new Set(fs.readFileSync(this.unindexFilePath, 'utf-8').split('\n'))
        } catch (e) {
            console.warn(`读取未被索引的url失败, 当作空文件处理, ${this.unindexFilePath}`)
        }
        console.log(`读取未被索引的url数量, ${unindexSet.size}`)
        return unindexSet
    }

    // 根据未建立好索引数据的url, 读取到对应的数据
    // @Override
    async getUnindexDataListLogic(unindexSet) {
        const allDataList = await this.store.getAllDataList()
        return allDataList.filter(item => unindexSet.has(item.url))
    }

    // getUnindexDataListLogic返回有未索引的数据，建立好索引后触发，内存中的索引全量持久化，入参indexMeta为构建好的全量索引
    // @Override
    async indexMetaPersistLogic(indexMeta) {
        fs.writeFileSync(this.indexFilePath, JSON.stringify(indexMeta))
    }

    // 删除未缩印的数据记录
    // @Override
    async deleteIncrDataLogic() {
        if (fs.existsSync(this.unindexFilePath)) {
            fs.rmSync(this.unindexFilePath)
        }
    }
}