import Index from './Index.js'
import Redis from 'ioredis'

export default class RedisIndex extends Index {
    constructor(config, store) {
        super(config, store)
        // 初始化 Redis 客户端
        this.redisClient = new Redis({
            host: '127.0.0.1',
            port: 6379,
            db: 0
        })
        // Redis键命名
        this.dataType = store.dataType
        this.unindexKey = `crawler:${this.dataType}:unindexUrls` // 用于存储已爬取的URL(Set结构)
        this.indexKey = `crawler:${this.dataType}:index` // 用于存储索引数据(Hash结构)
        return this.constructorInit()
    }

    // 记录索引没有持久化的数据
    // @Override
    async flushUnindexUrl(incrUrlSet) {
        if (incrUrlSet.size > 0) {
            await this.redisClient.sadd(this.unindexKey, ...incrUrlSet)
        }
    }

    // 读取构建好的索引，返回构建好的索引
    // @Override
    async indexMetaReadLogic() {
        return await this.redisClient.hgetall(this.indexKey)
    }

    // 读取未建立好索引数据的url
    // @Override
    async getUnindexUrlSetLogic() {
        const value = await this.redisClient.smembers(this.unindexKey)
        let unindexSet = new Set()
        if (value) {
            unindexSet = new Set(value)
        }
        return unindexSet
    }

    // 根据未建立好索引数据的url, 读取到对应的数据
    // @Override
    async getUnindexDataListLogic(unindexSet) {
        const allDataList = await this.store.getAllDataList()
        return allDataList.filter(item => unindexSet.has(item.url))
    }

    // getUnindexDataListLogic返回有未索引的数据，建立好索引后触发，内存中的索引全量持久化，入参indexMeta为构建好的全量索引
    // @Override
    async indexMetaPersistLogic(indexMeta) {
        await this.redisClient.hmset(this.indexKey, indexMeta)
    }

    // 删除未索引的数据记录
    // @Override
    async deleteIncrDataLogic() {
        await this.redisClient.del(this.unindexKey)
    }
}