import Flexsearch from 'flexsearch'
import Segment from 'segment'
import createDOMPurify from 'dompurify'
import { JSDOM } from 'jsdom'
import _ from 'lodash'

const DOMPurify = createDOMPurify(new JSDOM().window)
const segment = new Segment()
segment.useDefault()

export default class Index {
    constructor(config, store) {
        this.initConfig(config)
        this.store = store
        this.store.on("flush", async event => {
            // 新数据建立索引
            await this.addToIndex(event.newDataList)
            // 记录数据未被索引
            await this.flushUnindexUrl(event.incrUrlSet)
        })
        this.index = new Flexsearch.Document({
            document: {
                id: this.config.id,
                index: this.config.index,
                store: this.config.store
            }
        })
    }

    initConfig(config) {
        config = config ? config : {}
        config.id = config.id || "id"
        if (!config.id) {
            throw new Error("[索引配置校验]没有指定id字段config.id")
        }
        console.log(config)
        if (_.isEmpty(config.index)) {
            throw new Error("[索引配置校验]没有指定索引字段config.index")
        }
        config.store = config.store || []
        const storeFields = [...config.index, ...config.store]
        config.store = [...new Set(storeFields)]
        config.originIndex = [...config.index]
        config.index = config.originIndex.map(field => this.doGetSplitWordField(field))
        this.config = config
        console.log("[索引配置]", this.config)
    }

    constructorInit() {
        return new Promise((resolve, reject) => {
            this.import().then(() => {
                resolve(this)
            }).catch(error => {
                reject(error)
            })
        })
    }

    search(keyword) {
        const result = this.index.search(keyword, { index: this.config.index, enrich: true })
        let allDocList = []
        for (const fieldResult of result) {
            allDocList.push(...fieldResult.result)
        }
        allDocList = this.uniqueArray(allDocList)
        return allDocList
    }

    async addToIndex(dataList) {
        const docList = dataList.map(data => {
            // 使用指定的字段构建文档(多余的字段去掉)
            const doc = {}
            doc.id = data.id
            for (const field of this.config.originIndex) {
                doc[field] = data[field]
            }
            for (const field of this.config.store) {
                doc[field] = data[field]
            }
            return doc
        })
        return this.addDocument(docList)
    }

    addDocument(document) {
        if (!document) {
            return
        }
        const documentList = Array.isArray(document) ? document : [document]
        for (const doc of documentList) {
            this.index.add(this.doSegment(doc, this.config.originIndex))
        }
    }

    /**
     * 把内存中的索引导出到持久化存储中
     */
    async export() {
        const indexMeta = {}
        await this.index.export(function(key, data) {
            indexMeta[key] = data
        })
        await this.indexMetaPersistLogic(indexMeta)
    }

    /**
     * 把内存中的索引导出到持久化存储中
     */
    async import() {
        const indexMeta = await this.indexMetaReadLogic()
        if (indexMeta) {
            const promiseList = []
            for (const [key, value] of Object.entries(indexMeta)) {
                promiseList.push(this.index.import(key, value))
            }
            await Promise.all(promiseList)
        }

        const unindexSet = await this.getUnindexUrlSetLogic()
        const unindexDataList = await this.getUnindexDataListLogic(unindexSet)
        if (!_.isEmpty(unindexDataList)) {
            // 未被索引的数据建立索引
            await this.addToIndex(unindexDataList)
            // 全量导出索引
            await this.export()
        }
        // 删除未索引的增量数据
        await this.deleteIncrDataLogic()
    }

    async flushUnindexUrl(incrUrlSet) {
        throw new Error("Not Implemented")
    }

    async indexMetaReadLogic() {
        throw new Error("Not Implemented")
    }

    async getUnindexUrlSetLogic() {
        throw new Error("Not Implemented")
    }

    async getUnindexDataListLogic() {
        throw new Error("Not Implemented")
    }

    async indexMetaPersistLogic(indexMeta) {
        throw new Error("Not Implemented")
    }

    async deleteIncrDataLogic() {
        throw new Error("Not Implemented")
    }

    doSegment(document, fields) {
        for (const field of fields) {
            if (typeof document[field] === 'string') {
                const tokens = this.doSegmentText(document[field])
                document[this.doGetSplitWordField(field)] = tokens
            }
        }
        return document
    }

    doSegmentText(text) {
        text = this.doCleanHtml(text)
        return segment.doSegment(text, {
            stripPunctuation: true // 去除标点符号
        }).map(item => item.w).join(" ")
    }

    doCleanHtml(html) {
        const cleanedHtml = DOMPurify.sanitize(html, {
            USE_PROFILES: { html: true }
        })
        return cleanedHtml.replace(/<[^>]+>/g, ' ')
    }

    doGetSplitWordField(fieldName) {
        return fieldName + "_w"
    }

    uniqueArray(arr) {
        const idSet = new Set()
        const uniqueArr = []
        arr.forEach(item => {
            if (!idSet.has(item.id)) {
                idSet.add(item.id)
                uniqueArr.push(item)
            }
        })
        return uniqueArr
    }

}