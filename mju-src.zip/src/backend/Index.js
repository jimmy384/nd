import Flexsearch from 'flexsearch'
import Segment from 'segment'
import createDOMPurify from 'dompurify'
import { JSDOM } from 'jsdom'

const DOMPurify = createDOMPurify(new JSDOM().window)
const segment = new Segment()
segment.useDefault()

export default class Index {
    constructor() {
        this.index = new Flexsearch.Document({
            document: {
                id: 'id',
                index: ['title', 'content'],
                store: true
            }
        })
    }

    search(keyword) {
        return this.index.search(keyword, { index: ["title", "content"], enrich: true })
    }

    addDocument(document) {
        if (!document) {
            return
        }
        const documentList = Array.isArray(document) ? document : [document]
        for (const doc of documentList) {
            this.index.add(this.doSegment(doc, ['title', 'content']))
        }
    }

    doSegment(document, fields) {
        if (!fields) {
            return document
        }
        for (const field of fields) {
            if (typeof document[field] === 'string') {
                const tokens = this.doSegmentText(document[field])
                document[field] = tokens
            }
        }
        return document
    }

    doSegmentText(text) {
        text = this.doCleanHtml(text)
        return segment.doSegment(text, {
            stripPunctuation: true // 去除标点符号
        }).map(item => item.w).join(" ")
    }

    doCleanHtml(html) {
        const cleanedHtml = DOMPurify.sanitize(html, {
            USE_PROFILES: { html: true }
        })
        return cleanedHtml.replace(/<[^>]+>/g, ' ')
    }
}