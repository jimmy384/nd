import CrawlerDataFileStore from './store/CrawlerDataFileStore.js'
import CrawlerDataRedisStore from './store/CrawlerDataRedisStore.js'
import FileIndex from './index/FileIndex.js'
import RedisIndex from './index/RedisIndex.js'

const crawlerDataStoreMap = new Map()

export function customizeRouter(router) {
    router.post('/store/data', async ctx => {
        const crawlerDataStore = await getCrawlerDataStore(ctx)
        await crawlerDataStore.addIncrData(ctx.request.body)
        ctx.body = { success: true }
    })

    router.post('/url/uncrawled', async ctx => {
        const crawlerDataStore = await getCrawlerDataStore(ctx)
        const urlList = ctx.request.body
        const uncrawledList = await crawlerDataStore.filterUncrawled(urlList)
        ctx.body = uncrawledList
    })

    router.post('/search', async ctx => {
        const crawlerDataIndex = await getCrawlerDataIndex(ctx)
        const keyword = ctx.query["keyword"]
        ctx.body = await crawlerDataIndex.search(keyword)
    })

    router.post('/reload', async ctx => {
        crawlerDataStoreMap.clear()
        ctx.body = { success: true }
    })
}

async function getCrawlerDataComponent(ctx) {
    const dataType = ctx.query["dataType"]
    if (!dataType) {
        throw new Error("参数中缺少dataType")
    }
    if (!crawlerDataStoreMap[dataType]) {
        const crawlerDataStore = await new CrawlerDataRedisStore(dataType)
        const crawlerDataIndex = await new FileIndex({
            index: ["title", "content"]
        }, crawlerDataStore)
        crawlerDataStoreMap[dataType] = {
            crawlerDataStore,
            crawlerDataIndex
        }
    }
    return crawlerDataStoreMap[dataType]
}

async function getCrawlerDataStore(ctx) {
    await getCrawlerDataComponent(ctx).crawlerDataStore
}

async function getCrawlerDataIndex(ctx) {
    await getCrawlerDataComponent(ctx).crawlerDataIndex
}