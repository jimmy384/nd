import CrawlerDataFileStore from './store/CrawlerDataFileStore.js'
import CrawlerDataRedisStore from './store/CrawlerDataRedisStore.js'

const crawlerDataStoreMap = new Map()

export function customizeRouter(router) {
    router.post('/store/data', async ctx => {
        const crawlerDataStore = getCrawlerDataStore(ctx)
        await crawlerDataStore.addIncrData(ctx.request.body)
        ctx.body = { success: true }
    })

    router.post('/url/uncrawled', async ctx => {
        const crawlerDataStore = getCrawlerDataStore(ctx)
        const urlList = ctx.request.body
        const uncrawledList = await crawlerDataStore.filterUncrawled(urlList)
        ctx.body = uncrawledList
    })

    router.post('/search', async ctx => {
        const crawlerDataStore = getCrawlerDataStore(ctx)
        const keyword = ctx.query["keyword"]
        ctx.body = await crawlerDataStore.search(keyword)
    })
}

function getCrawlerDataStore(ctx) {
    const dataType = ctx.query["dataType"]
    if (!dataType) {
        throw new Error("参数中缺少dataType")
    }
    if (!crawlerDataStoreMap[dataType]) {
        const crawlerDataStore = new CrawlerDataRedisStore(dataType)
        crawlerDataStore.init()
        crawlerDataStoreMap[dataType] = crawlerDataStore
    }
    return crawlerDataStoreMap[dataType]
}
