import CrawlerDataFileStore from './store/CrawlerDataFileStore.js'
import CrawlerDataRedisStore from './store/CrawlerDataRedisStore.js'

const crawlerDataStore = new CrawlerDataRedisStore("ero")

export function customizeRouter(router) {
    crawlerDataStore.init()

    router.post('/store/data', async ctx => {
        await crawlerDataStore.addIncrData(ctx.request.body)
        ctx.body = { success: true }
    })

    router.post('/url/uncrawled', async ctx => {
        const urlList = ctx.request.body
        const uncrawledList = await crawlerDataStore.filterUncrawled(urlList)
        ctx.body = uncrawledList
    })
}
