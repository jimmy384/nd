import AbstractHttpClient from "./AbstractHttpClient"

export class ChromeExtensionHttpClient extends AbstractHttpClient {
    constructor() {
        super()
    }

    async sendRequest(config) {
        return new Promise((resolve, reject) => {
            reject("Not implemented")
        })
    }
}

export default ChromeExtensionHttpClient