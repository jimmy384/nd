import CurlHelper from "../curl/CurlHelper"
import AbstractCrawler from "./AbstractCrawler"
import AutoChooseHttpClient from "../common/http/AutoChooseHttpClient"
import { tryCatch } from "../common/ErrorHelper"
import _ from "lodash"

/**
 * 可以处理以下类型的页面
 * 1.列表-详情页面
 * 2.单个详情页面
 */
class ListDetailPageCrawler extends AbstractCrawler {
    /**
     * 请求页面、结果字段提取的配置
     */
    flowDefinition
    /**
     * 发送爬取数据请求的客户端
     */
    httpClient
    /**
     * 与爬虫数据存储端交互的客户端
     */
    crawlerStoreClient

    constructor(flowDefinition, crawlerStoreClient) {
        super()
        if (flowDefinition.listPage) {
            flowDefinition.listPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.listPage)
        }
        if (flowDefinition.detailPage) {
            flowDefinition.detailPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.detailPage)
        }
        this.flowDefinition = flowDefinition
        if (!this.getDataType()) {
            throw new Error("[爬虫配置]flowDefinition缺少dataType声明爬取的数据类型")
        }
        this.httpClient = new AutoChooseHttpClient()
        this.crawlerStoreClient = crawlerStoreClient || {
            removeCrawled: async (pageDataList, dataInfo) => pageDataList,
            saveCrawled: async (completedResult, dataInfo) => {},
        }
    }

    async callFlow(param) {
        param = !param ? { pageNum: 1 } : param
        param.pageNum = !param.pageNum ? 1 : param.pageNum
        const { pageNum } = param
        const flowInst = JSON.parse(JSON.stringify(this.flowDefinition))
        const { listPage: listPageDef, detailPage: detailPageDef } = flowInst

        // 存储某一页列表页面和这一页所有详情的信息
        const context = { pageNum }

        // 请求列表页面
        const listPageInfo = await this.crawleListPage(context, listPageDef)

        // 循环列表页面中的每一个详情页
        await this.crawleDetailPage(context, detailPageDef, param, pageNum)

        // 抓取下一页
        if (listPageInfo) {
            const hasNextPage = listPageInfo.totalPage && pageNum < listPageInfo.totalPage || listPageInfo.hasNextPage
            if (hasNextPage && (param.maxPageNum && pageNum < param.maxPageNum)) {
                param.pageNum++
                this.callFlow(param)
            }
        }
    }

    async crawleListPage(context, listPageDef) {
        if (listPageDef) {
            const { pageNum } = context
            const requestConfig = this.getListRequestConfig(listPageDef, context)
            // 提取列表页面信息
            console.log(`请求第${pageNum}页列表页面`)
            const listPageData = await this.sendRequest(requestConfig).catch(error => {
                console.log(`请求第${pageNum}页列表页面失败`, error)
                throw error
            })
            const listPageInfo = this.handleFields(listPageData, listPageDef.fields)
            console.log(`提取第${pageNum}页列表页面信息`, listPageInfo)
            context.listPage = listPageInfo
            return listPageInfo
        }
        return null
    }

    async crawleDetailPage(context, detailPageDef, param) {
        if (detailPageDef) {
            const { pageNum } = context
            context.detailPage = []
            const isListDetailPage = this.isListDetailPage(detailPageDef)
            let pageDataList = isListDetailPage ? this.doEval(detailPageDef.collection, context) : [context]
            pageDataList = this.jqueryListToArray(pageDataList)
            this.getDetailRequestConfig(pageDataList, detailPageDef, context)
            if (isListDetailPage) {
                pageDataList = await this.crawlerStoreClient.removeCrawled(pageDataList, { dataType: this.getDataType() })
                if (pageDataList.length > 0) {
                    this.doCrawleDetailPage(context, pageDataList, detailPageDef, param)
                } else {
                    console.log(`第${pageNum}页的数据之前就被爬取过`)
                }
            } else {
                this.doCrawleDetailPage(context, pageDataList, detailPageDef, param)
            }
        }
    }

    doCrawleDetailPage(context, pageDataList, detailPageDef, param) {
        const { pageNum } = context
        const isListDetailPage = this.isListDetailPage(detailPageDef)
        const detailPagePromiseList = pageDataList.map(async (listItem) => {
            // 请求详情页面
            const { requestConfig } = listItem
            const [error, detailPageData] = await tryCatch(this.sendRequest(requestConfig))
            if (error) {
                console.log(`第${pageNum}页详情页面${requestConfig.url}请求失败`, error)
                throw error
            }
            // 把结果临时保存到item中，方便后续处理
            listItem.detailPageInfo = this.handleFields(detailPageData, detailPageDef.fields)
            return listItem
        })

        console.log(`第${pageNum}页详情页面已提交到异步任务执行`)

        const successDetailPageList = []
        const failDetailPageList = []
        Promise.allSettled(detailPagePromiseList).then(resultList => {
            resultList.forEach((result, index) => {
                const listItem = pageDataList[index]
                const { requestConfig, detailPageInfo } = listItem
                delete listItem.requestConfig
                delete listItem.detailPageInfo
                if (result.status === "fulfilled") {
                    successDetailPageList.push({ listItem, requestConfig, detailItem: detailPageInfo })
                } else {
                    failDetailPageList.push({ listItem, requestConfig, errMsg: result.reason.message })
                }
            })
            console.log(`第${pageNum}详情页面抓取完成, 失败数量:${failDetailPageList.length}`)
            context.detailPage = isListDetailPage ? context.detailPage : context.detailPage[0]
            let completedResult
            if (isListDetailPage) {
                // 分页-详情结构的情况，把每个详情页成功失败的情况返回
                completedResult = {
                    successDetailPageList,
                    failDetailPageList
                }
            } else {
                // 单个详情页的情况，返回这个详情页的结果
                completedResult = {
                    successDetailPage: successDetailPageList.length > 0 ? successDetailPageList[0] : null,
                    failDetailPage: failDetailPageList.length > 0 ? failDetailPageList[0] : null,
                }
            }
            this.crawlerStoreClient.saveCrawled(completedResult, { dataType: this.getDataType() })
            param.onCompleted && param.onCompleted(completedResult, context)
        })
    }

    getListRequestConfig(listPageDef, context) {
        const requestConfig = {}
        if (listPageDef.url) {
            this.copyToRequestConfig(requestConfig, listPageDef)
            requestConfig.url = this.doEval("`" + this.flowDefinition.listPage.url + "`", context)
        }
        if (listPageDef.curl) {
            const curl = this.doEval("`" + this.flowDefinition.listPage.curl + "`", context)
            const requestInfo = CurlHelper.parse(curl)
            this.copyToRequestConfig(requestConfig, requestInfo)
        }
        return requestConfig
    }

    getDetailRequestConfig(pageDataList, detailPageDef, context) {
        const itemKey = detailPageDef.item || "item"
        return pageDataList.map(listItem => {
            // 获取详情页地址
            const detailEvalCtx = Object.assign({}, context)
            detailEvalCtx[itemKey] = listItem
            const requestConfig = {}
            if (this.flowDefinition.detailPage.url) {
                const url = this.doEval("`" + this.flowDefinition.detailPage.url + "`", detailEvalCtx)
                this.copyToRequestConfig(requestConfig, detailPageDef)
                requestConfig.url = url
                listItem.requestConfig = requestConfig
            }
            if (this.flowDefinition.detailPage.curl) {
                const curl = this.doEval("`" + this.flowDefinition.detailPage.curl + "`", detailEvalCtx)
                const requestInfo = CurlHelper.parse(curl)
                this.copyToRequestConfig(requestConfig, requestInfo)
                listItem.requestConfig = requestConfig
            }
            return requestConfig
        })
    }

    isListDetailPage(detailPage) {
        return detailPage.collection != null // 没有配置collection，则认为是单个详情页
    }

    getDataType() {
        return this.flowDefinition.dataType
    }

    copyToRequestConfig(requestConfig, requestInfo) {
        if (requestInfo) {
            if (requestInfo.params) {
                requestConfig.url = requestInfo.url + "?" + new URLSearchParams(requestInfo.params).toString()
            } else {
                requestConfig.url = requestInfo.url
            }
            requestConfig.method = requestInfo.method || "GET"
            requestConfig.headers = requestInfo.headers || {}
            if (requestInfo.method !== "GET" && requestInfo.method !== "HEAD") {
                requestConfig.data = requestInfo.data
            }
        }
        return requestConfig
    }

    /**
     * 接收一个请求config对象(axios格式)，返回一个Promise 
     */
    async sendRequest(requestConfig) {
        return this.httpClient.sendRequest(requestConfig)
    }
}

export default ListDetailPageCrawler