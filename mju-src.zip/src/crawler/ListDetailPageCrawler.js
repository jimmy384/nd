import CurlHelper from "../curl/CurlHelper"
import AbstractCrawler from "./AbstractCrawler"
import AutoChooseHttpClient from "./http/AutoChooseHttpClient"
import { tryCatch } from "../common/ErrorHelper"
import _ from "lodash"

/**
 * 可以处理以下类型的页面
 * 1.列表-详情页面
 * 2.单个详情页面
 */
class ListDetailPageCrawler extends AbstractCrawler {
    /**
     * 请求页面、结果字段提取的配置
     */
    flowDefinition
    /**
     * 发送请求函数，接收一个config对象(axios格式)，返回一个Promise
     */
    abstractHttpClient
    /**
     * 一些配置项
     */
    config

    constructor(flowDefinition, config) {
        super()
        if (flowDefinition.listPage) {
            flowDefinition.listPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.listPage)
        }
        if (flowDefinition.detailPage) {
            flowDefinition.detailPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.detailPage)
        }
        this.flowDefinition = flowDefinition
        this.abstractHttpClient = new AutoChooseHttpClient()
        this.config = config
        // 后端接口报错的时候是否中断爬虫，默认中断
        this.config.crawlerBackendUrl = this.config.crawlerBackendUrl || "http://localhost:3000"
        this.config.interuptOnBackendError = this.config.interuptOnBackendError === undefined ? true : this.config.interuptOnBackendError
    }

    async callFlow(config) {
        config = !config ? { pageNum: 1 } : config
        config.pageNum = !config.pageNum ? 1 : config.pageNum
        const { pageNum } = config
        const flowInst = JSON.parse(JSON.stringify(this.flowDefinition))
        const { listPage: listPageDef, detailPage: detailPageDef } = flowInst

        // 存储某一页列表页面和这一页所有详情的信息
        const context = { pageNum }

        // 请求列表页面
        const listPageInfo = await this.crawleListPage(context, listPageDef)

        // 循环列表页面中的每一个详情页
        if (detailPageDef) {
            context.detailPage = []
            const isListDetailPage = this.isListDetailPage(detailPageDef)
            let list = isListDetailPage ? this.doEval(detailPageDef.collection, context) : [context]
            list = this.jqueryListToArray(list)
            this.getDetailRequestConfig(list, detailPageDef, context)
            if (isListDetailPage) {
                list = await this.removeCrawled(list)
                if (list.length > 0) {
                    this.crawleDetailPage(context, list, detailPageDef, config)
                } else {
                    console.log(`第${pageNum}页的数据之前就被爬取过`)
                }
            } else {
                this.crawleDetailPage(context, list, detailPageDef, config)
            }
        }

        // 抓取下一页
        if (listPageDef) {
            const hasNextPage = context.listPage.totalPage && pageNum < context.listPage.totalPage || context.listPage.hasNextPage
            if (hasNextPage && (config.maxPageNum && pageNum < config.maxPageNum)) {
                config.pageNum++
                this.callFlow(config)
            }
        }
    }

    async crawleListPage(context, listPageDef) {
        const { pageNum } = context
        if (listPageDef) {
            const requestConfig = this.getListRequestConfig(listPageDef, context)
            // 提取列表页面信息
            console.log(`开始请求第${pageNum}页列表页面`)
            const listPageData = await this.sendRequest(requestConfig).catch(error => {
                console.log(`第${pageNum}页列表页面请求失败`, error)
                throw error
            })
            const listPageInfo = this.handleFields(listPageData, listPageDef.fields)
            context.listPage = listPageInfo
            return listPageInfo
        }
        return {}
    }

    isListDetailPage(detailPage) {
        return detailPage.collection != null // 没有配置collection，则认为是单个详情页
    }

    getListRequestConfig(listPage, context) {
        const requestConfig = {}
        if (listPage.url) {
            this.copyToRequestConfig(requestConfig, listPage)
            requestConfig.url = this.doEval("`" + this.flowDefinition.listPage.url + "`", context)
        }
        if (listPage.curl) {
            const curl = this.doEval("`" + this.flowDefinition.listPage.curl + "`", context)
            const requestInfo = CurlHelper.parse(curl)
            this.copyToRequestConfig(requestConfig, requestInfo)
        }
        return requestConfig
    }

    getDetailRequestConfig(list, detailPage, context) {
        const itemKey = detailPage.item || "item"
        return list.map(item => {
            // 获取详情页地址
            const detailEvalCtx = Object.assign({}, context)
            detailEvalCtx[itemKey] = item
            const requestConfig = {}
            if (this.flowDefinition.detailPage.url) {
                const url = this.doEval("`" + this.flowDefinition.detailPage.url + "`", detailEvalCtx)
                this.copyToRequestConfig(requestConfig, detailPage)
                requestConfig.url = url
                item.requestConfig = requestConfig
            }
            if (this.flowDefinition.detailPage.curl) {
                const curl = this.doEval("`" + this.flowDefinition.detailPage.curl + "`", detailEvalCtx)
                const requestInfo = CurlHelper.parse(curl)
                this.copyToRequestConfig(requestConfig, requestInfo)
                item.requestConfig = requestConfig
            }
            return requestConfig
        })
    }

    copyToRequestConfig(requestConfig, requestInfo) {
        if (requestInfo) {
            if (requestInfo.params) {
                requestConfig.url = requestInfo.url + "?" + new URLSearchParams(requestInfo.params).toString()
            } else {
                requestConfig.url = requestInfo.url
            }
            requestConfig.method = requestInfo.method || "GET"
            requestConfig.headers = requestInfo.headers || {}
            if (requestInfo.method !== "GET" && requestInfo.method !== "HEAD") {
                requestConfig.data = requestInfo.data
            }
        }
        return requestConfig
    }

    /**
     * 过滤出还没抓去过的页面，返回一个未抓取过的list
     */
    async removeCrawled(list) {
        const urlList = list.map(item => item.requestConfig.url)
        let [err, uncrawledList] = await tryCatch(this.abstractHttpClient.sendRequest({
            url: `${this.config.crawlerBackendUrl}/url/uncrawled`,
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            data: urlList
        }))
        if (err) {
            console.error("过滤出还没抓去过的url列表失败", err)
            uncrawledList = list.map(item => item.requestConfig.url)
            if (this.config.interuptOnBackendError) {
                throw err
            }
        }
        _.remove(list, item => !uncrawledList.includes(item.requestConfig.url))
        return list
    }

    crawleDetailPage(context, list, detailPage, config) {
        const { pageNum } = context
        const isListDetailPage = this.isListDetailPage(detailPage)
        const detailPageInfoList = context.detailPage
        const detailPagePromiseList = list.map(async (item) => {
            // 请求详情页面
            const { requestConfig } = item
            const [error, detailPageData] = await tryCatch(this.sendRequest(requestConfig))
            if (error) {
                console.log(`第${pageNum}页第${detailPageInfoList.length}个详情页面请求失败`, error)
                throw error
            }
            const detailPageInfo = this.handleFields(detailPageData, detailPage.fields)
            detailPageInfo.url = requestConfig.url
            detailPageInfoList.push(detailPageInfo)
            return item
        })

        console.log(`第${pageNum}页详情页面已提交到异步任务执行`)

        const successDetailPageList = []
        const failDetailPageList = []
        Promise.allSettled(detailPagePromiseList).then(resultList => {
            resultList.forEach((result, index) => {
                const item = list[index]
                const { requestConfig } = item
                delete item.requestConfig
                if (result.status === "fulfilled") {
                    successDetailPageList.push({ item, requestConfig, result: result.value })
                } else {
                    failDetailPageList.push({ item, requestConfig, errMsg: result.reason.message })
                }
            })
            console.log(`第${pageNum}详情页面抓取完成, 失败数量:${failDetailPageList.length}`)
            context.detailPage = isListDetailPage ? context.detailPage : context.detailPage[0]
            let completedResult
            if (isListDetailPage) {
                // 分页-详情结构的情况，把每个详情页成功失败的情况返回
                completedResult = {
                    successDetailPageList,
                    failDetailPageList
                }
            } else {
                // 单个详情页的情况，返回这个详情页的结果
                completedResult = successDetailPageList.length > 0 ? successDetailPageList[0] : failDetailPageList[0]
            }
            config.onCompleted && config.onCompleted(completedResult, context)
        })
    }

    async sendRequest(requestConfig) {
        return this.abstractHttpClient.sendRequest(requestConfig)
    }

    jqueryListToArray(list) {
        return list.jquery ? list.toArray() : list
    }
}

export default ListDetailPageCrawler