import AutoChooseHttpClient from "../common/http/AutoChooseHttpClient"
import { tryCatch } from "../common/ErrorHelper"
import _ from "lodash"

/**
 * 爬虫数据存储接口
 */
export default class CrawlerStoreClient {
    constructor(config) {
        this.httpClient = new AutoChooseHttpClient()
        this.config = config
        // 后端接口报错的时候是否中断爬虫，默认中断
        this.config.crawlerBackendUrl = this.config.crawlerBackendUrl || "http://localhost:3000"
        this.config.interuptOnBackendError = this.config.interuptOnBackendError === undefined ? true : this.config.interuptOnBackendError
        if (!this.config.dataType) {
            throw new Error("dataType不能为空")
        }
    }

    /**
     * 过滤出还没抓取过的页面，返回一个未抓取过的list
     */
    async removeCrawled(pageDataList) {
        const urlList = pageDataList.map(listItem => listItem.requestConfig.url)
        let [err, uncrawledList] = await tryCatch(this.httpClient.sendRequest({
            url: `${this.config.crawlerBackendUrl}/url/uncrawled?dataType=${this.config.dataType}`,
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            data: urlList
        }))
        if (err) {
            console.error("过滤出还没抓取过的url列表失败", err)
            uncrawledList = pageDataList.map(listItem => listItem.requestConfig.url)
            if (this.config.interuptOnBackendError) {
                throw err
            }
        }
        _.remove(pageDataList, listItem => !uncrawledList.includes(listItem.requestConfig.url))
        return pageDataList
    }

    async saveCrawled(completedResult) {
        if (completedResult instanceof Array) {
            completedResult = completedResult.map(item => item.result)
        } else {
            const { successDetailPageList, failDetailPageList } = completedResult
            const successDataList = []
            for (const successDetail of successDetailPageList) {
                successDataList.push({
                    "type": this.config.dataType,
                    "url": successDetail.requestConfig.url,
                    "data": Object.assign({}, successDetail.listItem, successDetail.detailItem, { url: successDetail.requestConfig.url })
                })
            }
            if (successDataList.length > 0) {
                console.log(successDataList)
                const result = await this.httpClient.sendRequest({
                    url: `${this.config.crawlerBackendUrl}/store/data?dataType=${this.config.dataType}`,
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    data: successDataList
                })
                console.log(result)
            }

            const failDataList = []
            for (const failDetail of failDetailPageList) {
                failDataList.push({
                    listItem: failDetail.listItem,
                    requestConfig: failDetail.requestConfig
                })
            }
            if (failDataList.length > 0) {
                console.log("失败的数据：", failDataList)
            }
        }
    }

}