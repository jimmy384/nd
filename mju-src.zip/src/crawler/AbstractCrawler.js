import $ from "jquery"
import { JSONPath } from "jsonpath-plus"

/**
 * 抽象爬虫
 * 封装从html, json中提取数据的能力
 */
class AbstractCrawler {
    constructor() {
        console.log("提取html的网页使用jquery, 提取json的响应使用jsonpath", typeof($))
    }

    handleFields(current, fields) {
        const info = {}
        if (fields) {
            for (const field of fields) {
                const { key, type } = field.key
                if (["simple", "arraySimple"].includes(type)) {
                    const extractValueFn = this.getExtractValueFn(field)
                    const value = extractValueFn.apply(this, [current, field])
                    info[key] = value
                } else if (type === "arrayObject") {
                    const extractValueFn = this.getExtractValueFn(field)
                    const elements = this.jqueryListToArray(extractValueFn.apply(this, [current, field]))
                    const value = elements.map(element => this.handleFields(element, field.fields))
                    info[key] = value
                } else {
                    console.warn(`[爬虫配置]不支持的类型type:${type}`)
                }
            }
        }
        return info
    }

    getExtractValueFn(field) {
        if (field.jsonPath) {
            return this.extractValueJsonPath
        } else if (field.selector) {
            return this.extractValueSelector
        } else {
            throw new Error(`[爬虫配置]field:${field.key}缺少配置jsonPath或者selector`)
        }
    }

    extractValueJsonPath(current, field) {
        const wrap = false
        const result = JSONPath({ path: field.jsonPath, json: current, wrap: wrap })
        if (field.type === "simple") {
            if (Array.isArray(result)) {
                return result.length > 0 ? result[0] : null
            } else {
                return result
            }
        } else {
            return result
        }
    }

    extractValueSelector(current, field) {
        return this.doEval(field.selector, { current: current })
    }

    doEval(script, context) {
        const argNames = Object.keys(context)
        const argValues = Object.values(context)
        const func = new Function(argNames, "return " + script)
        try {
            return func.apply(null, argValues)
        } catch (e) {
            console.error(`[爬虫配置]提取字段出错, 脚本:${script}`, context)
            throw e
        }
    }

    jqueryListToArray(list) {
        if (!list) {
            return list
        }
        return list.jquery ? list.toArray() : list
    }
}

export default AbstractCrawler