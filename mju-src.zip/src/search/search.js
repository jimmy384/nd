import Index from '../backend/Index.js'

const index = new Index()

index.addDocument([
    {
        id: "1",
        title: "Document 1",
        content: "This is the content of document 1"
    },
    {
        id: "2",
        title: "Document 2",
        content: "This is the content of document 2"
    }
])

const result = index.search("document 1")
console.log(result) // [{ id: '1', title: 'Document 1', content: 'This is the content of document 1' }]