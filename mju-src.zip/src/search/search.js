import CrawlerDataFileStore from '../backend/store/CrawlerDataFileStore.js'
import Index from '../backend/index/FileIndex.js'

await test()

async function test() {
    const store = await new CrawlerDataFileStore("test")
    const index = await new FileIndex({
        index: ["title", "content"]
    }, store)

    const result = await index.search("test")
    console.log(result)
}