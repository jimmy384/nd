export function tryCatch(logic) {
    if (logic instanceof Function) {
        try {
            const result = logic()
            return [ null, result ]
        } catch (err) {
            return [ err, null ]
        }
    } else if (logic instanceof Promise) {
        return logic
            .then(result => ([ null, result ]))
            .catch(err => ([ err, null ]))
    } else {
        new Error('logic必须是一个function或者promise')
    }
}

export default {
    tryCatch
}