export function detectEnvironment(config = {}) {
    if (isTampermonkey()) {
        config.tampermonkey && config.tampermonkey()
    } else if (isChromeExtension()) {
        config.chromeExtension && config.chromeExtension()
    } else {
        config.other && config.other()
    }
}

export function isTampermonkey() {
    return typeof GM_info !== 'undefined' || typeof GM_xmlhttpRequest !== 'undefined';
}

export function isChromeExtension() {
    return typeof chrome !== 'undefined' && typeof chrome.runtime !== 'undefined' && typeof chrome.runtime.id !== 'undefined';
}

export default {
    detectEnvironment,
    isTampermonkey,
    isChromeExtension
}