import AbstractHttpClient from "./AbstractHttpClient"
import TempermonkeyHttpClient from "./TempermonkeyHttpClient"
import ChromeExtensionHttpClient from "./ChromeExtensionHttpClient"
import EnvironmentHelper from "../EnvironmentHelper"

export class AutoChooseHttpClient extends AbstractHttpClient {
    constructor() {
        super()
        EnvironmentHelper.detectEnvironment({
            tampermonkey: () => {
                this.abstractHttpClient = new TempermonkeyHttpClient()
            },
            chromeExtension: () => {
                this.abstractHttpClient = new ChromeExtensionHttpClient()
            },
            other: () => {
                throw new Error("未知的运行环境")
            }
        })
    }

    async sendRequest(config) {
        return this.abstractHttpClient.sendRequest(config)
    }
}

export default AutoChooseHttpClient