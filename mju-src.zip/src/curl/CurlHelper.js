function parse(curl) {
	if (!curl || !curl.trim())
		return;

	// List of curl flags that are boolean typed; this helps with parsing
	// a command like `curl -abc value` to know whether 'value' belongs to '-c'
	// or is just a positional argument instead.
	// https://github.com/curl/curl/blob/f410b9e538129e77607fef1894f96c684a7c8c3b/src/tool_getparam.c#L73-L341
	var boolOptions = new Set([
		'disable-epsv', 'no-disable-epsv', 'disallow-username-in-url', 'no-disallow-username-in-url',
		'epsv', 'no-epsv', 'npn', 'no-npn', 'alpn', 'no-alpn', 'compressed', 'no-compressed',
		'tr-encoding', 'no-tr-encoding', 'digest', 'no-digest', 'negotiate', 'no-negotiate',
		'ntlm', 'no-ntlm', 'ntlm-wb', 'no-ntlm-wb', 'basic', 'no-basic', 'anyauth', 'no-anyauth',
		'wdebug', 'no-wdebug', 'ftp-create-dirs', 'no-ftp-create-dirs',
		'create-dirs', 'no-create-dirs', 'proxy-ntlm', 'no-proxy-ntlm', 'crlf', 'no-crlf',
		'haproxy-protocol', 'no-haproxy-protocol', 'disable-eprt', 'no-disable-eprt',
		'eprt', 'no-eprt', 'xattr', 'no-xattr', 'ftp-ssl', 'no-ftp-ssl', 'ssl', 'no-ssl',
		'ftp-pasv', 'no-ftp-pasv', 'tcp-nodelay', 'no-tcp-nodelay', 'proxy-digest', 'no-proxy-digest',
		'proxy-basic', 'no-proxy-basic', 'retry-connrefused', 'no-retry-connrefused',
		'proxy-negotiate', 'no-proxy-negotiate', 'proxy-anyauth', 'no-proxy-anyauth',
		'trace-time', 'no-trace-time', 'ignore-content-length', 'no-ignore-content-length',
		'ftp-skip-pasv-ip', 'no-ftp-skip-pasv-ip', 'ftp-ssl-reqd', 'no-ftp-ssl-reqd',
		'ssl-reqd', 'no-ssl-reqd', 'sessionid', 'no-sessionid', 'ftp-ssl-control', 'no-ftp-ssl-control',
		'ftp-ssl-ccc', 'no-ftp-ssl-ccc', 'raw', 'no-raw', 'post301', 'no-post301',
		'keepalive', 'no-keepalive', 'post302', 'no-post302',
		'socks5-gssapi-nec', 'no-socks5-gssapi-nec', 'ftp-pret', 'no-ftp-pret', 'post303', 'no-post303',
		'metalink', 'no-metalink', 'sasl-ir', 'no-sasl-ir', 'test-event', 'no-test-event',
		'path-as-is', 'no-path-as-is', 'tftp-no-options', 'no-tftp-no-options',
		'suppress-connect-headers', 'no-suppress-connect-headers', 'compressed-ssh', 'no-compressed-ssh',
		'retry-all-errors', 'no-retry-all-errors',
		'http1.0', 'http1.1', 'http2', 'http2-prior-knowledge', 'http3', 'http0.9', 'no-http0.9',
		'tlsv1', 'tlsv1.0', 'tlsv1.1', 'tlsv1.2', 'tlsv1.3', 'sslv2', 'sslv3',
		'ipv4', 'ipv6',
		'append', 'no-append', 'use-ascii', 'no-use-ascii', 'ssl-allow-beast', 'no-ssl-allow-beast',
		'ssl-auto-client-cert', 'no-ssl-auto-client-cert',
		'proxy-ssl-auto-client-cert', 'no-proxy-ssl-auto-client-cert', 'cert-status', 'no-cert-status',
		'doh-cert-status', 'no-doh-cert-status', 'false-start', 'no-false-start',
		'ssl-no-revoke', 'no-ssl-no-revoke', 'ssl-revoke-best-effort', 'no-ssl-revoke-best-effort',
		'tcp-fastopen', 'no-tcp-fastopen', 'proxy-ssl-allow-beast', 'no-proxy-ssl-allow-beast',
		'proxy-insecure', 'no-proxy-insecure', 'proxy-tlsv1', 'socks5-basic', 'no-socks5-basic',
		'socks5-gssapi', 'no-socks5-gssapi', 'fail', 'no-fail', 'fail-early', 'no-fail-early',
		'styled-output', 'no-styled-output', 'mail-rcpt-allowfails', 'no-mail-rcpt-allowfails',
		'fail-with-body', 'no-fail-with-body', 'globoff', 'no-globoff', 'get', 'help', 'no-help',
		'include', 'no-include', 'head', 'no-head', 'junk-session-cookies', 'no-junk-session-cookies',
		'remote-header-name', 'no-remote-header-name', 'insecure', 'no-insecure',
		'doh-insecure', 'no-doh-insecure', 'list-only', 'no-list-only', 'location', 'no-location',
		'location-trusted', 'no-location-trusted', 'manual', 'no-manual', 'netrc', 'no-netrc',
		'netrc-optional', 'no-netrc-optional', 'buffer', 'no-buffer', 'remote-name',
		'remote-name-all', 'no-remote-name-all', 'proxytunnel', 'no-proxytunnel', 'disable', 'no-disable',
		'remote-time', 'no-remote-time', 'silent', 'no-silent', 'show-error', 'no-show-error',
		'verbose', 'no-verbose', 'version', 'no-version', 'parallel', 'no-parallel',
		'parallel-immediate', 'no-parallel-immediate', 'progress-bar', 'no-progress-bar',
		'progress-meter', 'no-progress-meter', 'next',
		// renamed to --http3 in https://github.com/curl/curl/commit/026840e3
		'http3-direct',
		// replaced by --request-target in https://github.com/curl/curl/commit/9b167fd0
		'strip-path-slash', 'no-strip-path-slash',
		// removed in https://github.com/curl/curl/commit/a8e388dd
		'environment', 'no-environment',
		// curl technically accepted these non-sensical options, they were removed in
		// https://github.com/curl/curl/commit/913c3c8f
		'no-http1.0', 'no-http1.1', 'no-http2', 'no-http2-prior-knowledge',
		'no-tlsv1', 'no-tlsv1.0', 'no-tlsv1.1', 'no-tlsv1.2', 'no-tlsv1.3', 'no-sslv2', 'no-sslv3',
		'no-ipv4', 'no-ipv6', 'no-proxy-tlsv1', 'no-get', 'no-remote-name', 'no-next',
		// removed in https://github.com/curl/curl/commit/720ea577
		'proxy-sslv2', 'no-proxy-sslv2', 'proxy-sslv3', 'no-proxy-sslv3',
		// removed in https://github.com/curl/curl/commit/388c6b5e
		// I don't think this was ever a real short option
		// '~',
		// renamed to --http2 in https://github.com/curl/curl/commit/0952c9ab
		'http2.0', 'no-http2.0',
		// removed in https://github.com/curl/curl/commit/ebf31389
		// I don't think this option was ever released, it was renamed the same day
		// it was introduced
		// 'ssl-no-empty-fragments', 'no-ssl-no-empty-fragments',
		// renamed to --ntlm-wb in https://github.com/curl/curl/commit/b4f6319c
		'ntlm-sso', 'no-ntlm-sso',
		// all options got "--no-" versions in https://github.com/curl/curl/commit/5abfdc01
		// renamed to --no-keepalive in https://github.com/curl/curl/commit/f866af91
		'no-keep-alive',
		// may've been short for --crlf until https://github.com/curl/curl/commit/16643faa
		// '9',
		// removed in https://github.com/curl/curl/commit/07660eea
		// -@ used to be short for --create-dirs
		'ftp-ascii', // '@',
		// removed in https://github.com/curl/curl/commit/c13dbf7b
		// 'c', 'continue',
		// removed in https://github.com/curl/curl/commit/a1d6ad26
		// -t used to be short for --upload
		// 't', 'upload',
        // https://github.com/mholt/curl-to-go/pull/47#issuecomment-879485938
		'-',
	]);

	// all of curl's short options have a long form
	var optionAliases = {
		'0': 'http1.0',
		'1': 'tlsv1',
		'2': 'sslv2',
		'3': 'sslv3',
		'4': 'ipv4',
		'6': 'ipv6',
		'a': 'append',
		'A': 'user-agent',
		'b': 'cookie',
		'B': 'use-ascii',
		'c': 'cookie-jar',
		'C': 'continue-at',
		'd': 'data',
		'D': 'dump-header',
		'e': 'referer',
		'E': 'cert',
		'f': 'fail',
		'F': 'form',
		'g': 'globoff',
		'G': 'get',
		'h': 'help',
		'H': 'header',
		'i': 'include',
		'I': 'head',
		'j': 'junk-session-cookies',
		'J': 'remote-header-name',
		'k': 'insecure',
		'K': 'config',
		'l': 'list-only',
		'L': 'location',
		'm': 'max-time',
		'M': 'manual',
		'n': 'netrc',
		// N is an alias for --no-buffer, not --buffer
		'N': 'no-buffer',
		'o': 'output',
		'O': 'remote-name',
		'p': 'proxytunnel',
		'P': 'ftp-port',
		'q': 'disable',
		'Q': 'quote',
		'r': 'range',
		'R': 'remote-time',
		's': 'silent',
		'S': 'show-error',
		't': 'telnet-option',
		'T': 'upload-file',
		'u': 'user',
		'U': 'proxy-user',
		'v': 'verbose',
		'V': 'version',
		'w': 'write-out',
		'x': 'proxy',
		'X': 'request',
		'Y': 'speed-limit',
		'y': 'speed-time',
		'z': 'time-cond',
		'Z': 'parallel',
		'#': 'progress-bar',
		':': 'next',
	};

	var cmd = parseCommand(curl, { boolFlags: boolOptions, aliases: optionAliases });

	if (cmd._[0] != "curl")
		throw "Not a curl command";

	return extractRelevantPieces(cmd);

	function extractRelevantPieces(cmd) {
		var relevant = {
			url: "",
			method: "",
			headers: [],
			data: {},
			dataType: "string",
			insecure: false
		};

		// prefer --url over unnamed parameter, if it exists; keep first one only
		if (cmd.url && cmd.url.length > 0)
			relevant.url = cmd.url[0];
		else if (cmd._.length > 1)
			relevant.url = cmd._[1]; // position 1 because index 0 is the curl command itself

		// gather the headers together
		if (cmd.header)
			relevant.headers = relevant.headers.concat(cmd.header);
		relevant.headers = parseHeaders(relevant.headers)

		// set method to HEAD?
		if (cmd.head)
			relevant.method = "HEAD";

		if (cmd.request && cmd.request.length > 0)
			relevant.method = cmd.request[cmd.request.length-1].toUpperCase(); // if multiple, use last (according to curl docs)
		else if (
			(cmd["data-binary"] && cmd["data-binary"].length > 0)
			|| (cmd["data-raw"] && cmd["data-raw"].length > 0)
		 ) {
			 // for --data-binary and --data-raw, use method POST & data-type raw
			relevant.method = "POST";
			relevant.dataType = "raw";
		}

		// join multiple request body data, if any
		var dataAscii = [];
		var dataFiles = [];
		var loadData = function (d, dataRawFlag = false) {
			if (!relevant.method)
				relevant.method = "POST";

			// according to issue #8, curl adds a default Content-Type
			// header if one is not set explicitly
			if (!relevant.headers["Content-Type"])
				relevant.headers["Content-Type"] = "application/x-www-form-urlencoded";

			for (var i = 0; i < d.length; i++) {
				if (
					d[i].length > 0 && d[i][0] == "@"
					&& !dataRawFlag // data-raw flag ignores '@' character
				) {
					dataFiles.push(d[i].substr(1));
				} else {
					dataAscii.push(d[i]);
				}
			}
		};
		if (cmd.data)
			loadData(cmd.data);
		if (cmd["data-binary"])
			loadData(cmd["data-binary"]);
		if (cmd["data-raw"])
			loadData(cmd["data-raw"], true)
		if (dataAscii.length > 0)
			relevant.data.ascii = dataAscii.join("&");
		// 先不考虑文件的情况
		// if (dataFiles.length > 0)
		// 	relevant.data.files = dataFiles;
		if (relevant.data?.ascii) {
			relevant.data = relevant.data.ascii
		}

		var basicAuthString = "";
		if (cmd.user && cmd.user.length > 0)
			basicAuthString = cmd.user[cmd.user.length-1];
		// if the -u or --user flags haven't been set then don't set the
		// basicauth property.
		if (basicAuthString) {
			var basicAuthSplit = basicAuthString.indexOf(":");
			if (basicAuthSplit > -1) {
				relevant.basicauth = {
					user: basicAuthString.substr(0, basicAuthSplit),
					pass: basicAuthString.substr(basicAuthSplit+1)
				};
			} else {
				// the user has not provided a password
				relevant.basicauth = { user: basicAuthString, pass: "<PASSWORD>" };
			}
		}

		// default to GET if nothing else specified
		if (!relevant.method)
			relevant.method = "GET";

		if (cmd.insecure) {
			relevant.insecure = true;
		}

		return relevant;
	}

	// parseHeaders converts an array of header strings (like "Content-Type: foo")
	// into a map of key/values. It assumes header field names are unique.
	function parseHeaders(stringHeaders) {
		var headers = {};
		for (var i = 0; i < stringHeaders.length; i++) {
			var split = stringHeaders[i].indexOf(":");
			if (split == -1) continue;
			var name = stringHeaders[i].substr(0, split).trim();
			var value = stringHeaders[i].substr(split+1).trim();
			headers[toTitleCase(name)] = value;
		}
		return headers;
	}

	function toTitleCase(str) {
		return str.replace(/\w*/g, function(txt) {
			return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
		});
	}

}

function parseCommand(input, options) {
	if (typeof options === 'undefined') {
		options = {};
	}

	var result = {_: []}, // what we return
	    cursor = 0;       // iterator position

	// trim leading $ or # that may have been left in
	input = input.trim();
	if (input.length > 2 && (input[0] == '$' || input[0] == '#') && whitespace(input[1]))
		input = input.substr(1).trim();

	for (cursor = 0; cursor < input.length; cursor++) {
		skipWhitespace();
		if (input[cursor] == "-") {
			flagSet();
		} else {
			unflagged();
		}
	}

	return result;

	function flagSet() {
		// long flag form?
		if (cursor < input.length-1 && input[cursor+1] == "-") {
			return longFlag();
		}

		// if not, parse short flag form
		cursor++; // skip leading dash
		while (cursor < input.length && !whitespace(input[cursor]))
		{
			var flagName = fullName(input[cursor]);
			if (typeof result[flagName] == 'undefined') {
				result[flagName] = [];
			}
			cursor++; // skip the flag name
			if (boolFlag(flagName))
				result[flagName] = toBool(flagName);
			else if (Array.isArray(result[flagName]))
				result[flagName].push(nextString());
		}
	}

	// longFlag consumes a "--long-flag" sequence and
	// stores it in result.
	function longFlag() {
		cursor += 2; // skip leading dashes
		var flagName = nextString("=");
		if (boolFlag(flagName))
			result[flagName] = toBool(flagName);
		else {
			if (typeof result[flagName] == 'undefined') {
				result[flagName] = [];
			}
			if (Array.isArray(result[flagName])) {
				result[flagName].push(nextString());
			}
		}
	}

	// unflagged consumes the next string as an unflagged value,
	// storing it in the result.
	function unflagged() {
		result._.push(nextString());
	}

	// fullName returns the long name of a short flag
	function fullName(flag) {
		var alias = options.aliases[flag]
		return alias ? alias : flag;
	}

	// boolFlag returns whether a flag is known to be boolean type
	function boolFlag(flag) {
		if (options.boolFlags instanceof Set) {
			return options.boolFlags.has(flag);
		}
		if (Array.isArray(options.boolFlags)) {
			for (var i = 0; i < options.boolFlags.length; i++) {
				if (options.boolFlags[i] == flag)
					return true;
			}
		}
		return false;
	}

	// toBool converts a long flag name to a boolean value.
	// --verbose -> true
	// --no-verbose -> false
	function toBool(flag) {
		return !(flag.startsWith('no-') || flag.startsWith('disable-'));
	}

	// nextString skips any leading whitespace and consumes the next
	// space-delimited string value and returns it. If endChar is set,
	// it will be used to determine the end of the string. Normally just
	// unescaped whitespace is the end of the string, but endChar can
	// be used to specify another end-of-string. This function honors \
	// as an escape character and does not include it in the value, except
	// in the special case of the \$ sequence, the backslash is retained
	// so other code can decide whether to treat as an env var or not.
	function nextString(endChar) {
		skipWhitespace();

		var str = "";

		var quoted = false,
			quoteCh = "",
			escaped = false;
		var quoteDS = false; // Dollar-Single-Quotes

		for (; cursor < input.length; cursor++) {
			if (quoted) {
				if (input[cursor] == quoteCh && !escaped && input[cursor -1] != "\\") {
					quoted = false;
					continue;
				}
			}
			if (!quoted) {
				if (!escaped) {
					if (whitespace(input[cursor])) {
						return str;
					}
					if (input[cursor] == '"' || input[cursor] == "'") {
						quoted = true;
						quoteCh = input[cursor];
						if (str + quoteCh == "$'") {
							quoteDS = true
							str = ""
						}
						cursor++;
					}
					if (endChar && input[cursor] == endChar) {
						cursor++; // skip the endChar
						return str;
					}
				}
			}
			if (!escaped && !quoteDS && input[cursor] == "\\") {
				escaped = true;
				// skip the backslash unless the next character is $
				if (!(cursor < input.length-1 && input[cursor+1] == '$'))
					continue;
			}

			str += input[cursor];
			escaped = false;
		}

		return str;
	}

	// skipWhitespace skips whitespace between tokens, taking into account escaped whitespace.
	function skipWhitespace() {
		for (; cursor < input.length; cursor++) {
			while (input[cursor] == "\\" && (cursor < input.length-1 && whitespace(input[cursor+1])))
				cursor++;
			if (!whitespace(input[cursor]))
				break;
		}
	}

	// whitespace returns true if ch is a whitespace character.
	function whitespace(ch) {
		return ch == " " || ch == "\t" || ch == "\n" || ch == "\r";
	}
}

export default {
    parse
}