# 实现计划与进度清单

状态定义：
- `[x]`：代码已提供（不代表已完成生产级验收）。
- `[~]`：有骨架或设计，仍需补齐/集成验证。
- `[ ]`：尚未实现。

## 阶段 0：工程初始化

- [x] Python 3.12+ 项目结构
- [x] pyproject.toml / uv 依赖定义
- [x] Typer CLI 入口
- [ ] CI、格式化、静态检查（ruff/mypy）
- [ ] 版本发布和迁移策略

## 阶段 1：配置体系

- [x] project / connection / entity / compare / write 的 Pydantic 模型
- [x] YAML 安全加载
- [x] `${ENV}` 和 `${ENV:-default}` 环境变量解析
- [x] 未知字段禁止
- [x] 项目、实体、比较、写入配置组装
- [x] 基础跨文件引用校验
- [~] SQL 抽取列名运行时校验
- [~] 连接驱动与 dialect 组合校验
- [~] 写入目标表、列、主键映射完整性校验
- [ ] 配置不可变快照、脱敏、SHA-256 manifest
- [ ] 完整错误聚合与配置诊断报告

## 阶段 2：数据库连接与抽取

- [x] SQLAlchemy Engine 工厂
- [x] Engine 复用与 dispose
- [x] 基础 QueryExecutor / fetchmany
- [x] 统一字段 RecordMapper
- [x] Decimal 拒绝 float 隐式转换
- [x] 主键 NULL、重复、递增检查
- [x] JSONL SnapshotWriter / SnapshotReader
- [x] Decimal、date、datetime、time、binary 类型标记
- [x] 临时文件写入、完成后原子替换
- [x] SHA-256 和记录数
- [x] `test-connection` / `extract` CLI
- [~] PostgreSQL psycopg 服务端游标集成测试
- [~] MySQL PyMySQL 服务端游标集成测试
- [~] Oracle / SQL Server 驱动适配验证
- [~] 可取消抽取、进度回调、超时
- [~] 一致性快照策略
- [ ] 抽取任务状态持久化与恢复
- [ ] 大数据量内存、吞吐基准测试

## 阶段 3：统一模型与任务存储

- [x] UnifiedRecord 基础模型
- [~] Difference 基础领域模型；Decision / Task 待实现
- [ ] SQLite schema 和版本迁移
- [ ] TaskRepository
- [ ] DifferenceRepository
- [ ] DecisionRepository
- [ ] ArtifactRepository
- [ ] 批量写入、索引和分页查询
- [ ] 任务状态机与失败恢复

## 阶段 4：比对引擎

- [x] 双路有序归并（JSONL 输入、JSONL 差异输出；严格检测乱序/重复键）
- [x] 复合主键比较器（Python tuple 字典序；跨库 collation 仍需治理）
- [ ] 字符串 collation 统一策略
- [ ] 外部排序兜底
- [x] 字符串规范化规则（trim / case-sensitive）
- [x] Decimal 精度与 tolerance（先 quantize 再比较）
- [x] 日期时间精度、时区规范化（基础实现，需集成验证）
- [x] NULL 与空字符串策略
- [x] VALUE_DIFF / NEW_ONLY / OLD_ONLY
- [~] 稳定 difference_id；原值指纹尚未实现
- [ ] 分批写入 SQLite（当前先输出 JSONL）
- [x] CLI 比对统计（控制台摘要）
- [~] 乱序、重复键、基础规范化单元测试；边界值和性能测试待补

## 阶段 5：Excel 决策

- [ ] 差异明细 Sheet
- [ ] 记录级差异 Sheet
- [ ] 汇总和使用说明 Sheet
- [ ] 大数据量 write_only 导出
- [ ] read_only 导入
- [ ] NEW / OLD / MANUAL / IGNORE 决策
- [ ] NULL、空字符串、未填写三态编码
- [ ] 批次、差异 ID、指纹校验
- [ ] 重复决策、缺失决策、非法类型校验
- [ ] CSV 决策导入备选
- [ ] 决策报告

## 阶段 6：SQL 生成

- [ ] Write Definition 目标解析
- [ ] UpdateStatement 中间模型
- [ ] PostgreSQL Dialect
- [ ] MySQL Dialect
- [ ] Oracle Dialect
- [ ] SQL Server Dialect
- [ ] NULL 原值保护条件
- [ ] 原值变化冲突检测条件
- [ ] 多表写入顺序
- [ ] 安全 SQL 合并
- [ ] expected_rows 检查脚本
- [ ] 按库/实体/表拆分 SQL 文件
- [ ] manifest / README / 哈希
- [ ] dry-run 和 SQL 预览
- [ ] SQL 生成单元测试

## 阶段 7：验证闭环

- [ ] 人工执行后的新验证任务
- [ ] 原任务与验证任务关联
- [ ] 重新抽取和比对
- [ ] 已解决、未解决、新增差异统计
- [ ] 验证报告
- [ ] GENERATED 不直接视为 VERIFIED

## 阶段 8：可用性与发布

- [ ] Loguru 结构化日志和敏感信息脱敏
- [ ] CLI 帮助、错误码和进度显示
- [ ] 配置模板生成命令
- [ ] 示例项目与演示数据
- [ ] 文档、安装说明和升级说明
- [ ] 跨平台测试
- [ ] 备份与恢复说明
- [ ] 安全审查
- [ ] 端到端验收

## 推荐里程碑

| 里程碑 | 交付结果 | 进入条件 |
|---|---|---|
| M1 配置与抽取 | 可从两库抽取并保存快照 | 阶段 1、2 的集成测试通过 |
| M2 可比对 | 生成可靠差异列表 | 阶段 3、4 完成 |
| M3 可人工决策 | Excel 导入决策可追溯 | 阶段 5 完成 |
| M4 可生成校准 SQL | 输出安全 SQL、manifest | 阶段 6 完成 |
| M5 可验证闭环 | 人工执行后验证结果 | 阶段 7 完成 |
| M6 可交付 | 安装、文档、性能、安全验收 | 阶段 8 完成 |

## 当前真实进度说明

目前已有配置、抽取/快照基础实现，以及 M2 的 JSONL 双路归并比对实现和基础单元测试。SQLite 任务/差异存储、Excel 决策、SQL 生成和验证闭环仍未完成。即使清单标记 `[x]`，也仅表示对应基础代码已写入仓库；真实数据库兼容性、跨库排序语义和生产级可靠性仍需测试。
