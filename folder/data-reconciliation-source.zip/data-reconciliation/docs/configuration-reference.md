# 配置参考

本文件配合 `config/` 下示例使用。所有 YAML 均采用 UTF-8。

## 1. 连接

连接字段：
- `dialect`：postgresql/mysql/oracle/mssql。
- `driver`：SQLAlchemy driver 名称，例如 psycopg、pymysql。
- `url`：完整连接 URL；存在时优先使用。
- `username/password/host/port/database`：没有 URL 时构造连接 URL。
- `engine_options`：传递给 SQLAlchemy create_engine 的参数。
- `connect_args`：传递给 DBAPI driver 的参数。

不要把 Engine 参数放入 connect_args。

## 2. 实体

`keys` 是统一业务主键字段列表。`fields` 的 key 是 SQL 必须返回的列别名。`extract.new` 和 `extract.old` 分别定义两侧 SQL、连接和可选参数。

## 3. 比较规则

`compare.default` 定义默认规则；`compare.fields` 对单字段覆盖。Decimal tolerance 使用字符串，例如 `"0.01"`。

## 4. 写入映射

`write.new/old.fields.<field>.targets` 描述物理写入位置。每个 target 的 `keys` 必须把每个统一主键映射到物理键列。`writable: false` 表示不生成该字段的修改 SQL。
