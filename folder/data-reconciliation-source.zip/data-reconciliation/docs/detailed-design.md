# 数据库数据比对与校准工具详细设计

- 文档版本：0.1
- 状态：设计基线 + 第一阶段代码骨架
- 实现语言：Python 3.12+
- 目标：对业务概念相同、物理表结构不同的新旧数据库进行数据抽取、差异分析、人工决策和 SQL 文件生成。
- 重要边界：工具只生成 SQL 文件，不直接执行校准 SQL。

## 1. 背景与目标

新旧数据库可能存在表名、列名、字段类型不同的情况；一个统一业务实体在旧库中甚至需要 JOIN 多张表才能组装。工具通过用户编写两套查询 SQL，将数据映射到统一实体模型，再进行比较。

目标：
1. 配置驱动支持多个实体。
2. 支持新旧数据库独立 SQL、JOIN、复合主键。
3. 支持几万到几十万级数据，不将全部记录载入内存。
4. 将差异导出 Excel，供业务人员分析和决策。
5. 根据决策生成带原值保护条件的 SQL 文件。
6. 保存任务、快照、配置版本、差异、决策和生成记录，确保可追溯。
7. 工具不直接连接目标库执行 UPDATE。

非目标：
- 不提供 Web 管理界面（第一版）。
- 不自动推断新旧字段映射。
- 不自动执行生成的 SQL。
- 不承担跨数据库分布式事务。

## 2. 总体架构

```mermaid
flowchart TB
  CLI[Typer CLI] --> CM[Config Manager]
  CM --> CFG[Pydantic Config Models]
  CM --> CV[Config Validator]
  CLI --> EX[Extractor]
  EX --> CF[Connection Factory]
  EX --> QE[Query Executor]
  EX --> RM[Record Mapper]
  RM --> SW[Snapshot Writer]
  SW --> JSONL[JSONL Snapshots]
  JSONL --> CMP[Compare Engine]
  CMP --> DB[(SQLite Task Store)]
  DB --> XLS[Excel Export / Import]
  XLS --> DEC[Decision Validator]
  DEC --> SQL[SQL Generator]
  SQL --> ART[SQL + Manifest + README]
```

核心分层：
- Config：读取配置、结构校验、跨文件校验。
- Datasource：连接数据库、执行查询、流式读取。
- Model：统一记录、差异、决策、任务。
- Snapshot：类型保真快照。
- Comparator：有序归并和字段规范化比较。
- Excel：差异导出、决策导入。
- SQL：目标映射、Statement、方言 SQL 生成。
- Storage：SQLite 元数据持久化。
- Verification：新任务重新抽取和比对，验证人工执行结果。

## 3. 配置体系

配置目录：

```text
config/
  project.yaml
  connections.yaml
  entities/<entity>.yaml
  compare/<entity>.yaml
  write/<entity>.yaml
```

### 3.1 project.yaml

定义项目 ID、名称、配置版本、新旧连接逻辑角色、全局读取批次、工作目录和默认行为。

### 3.2 connections.yaml

连接 ID 与数据库类型解耦。支持 PostgreSQL、MySQL、Oracle、SQL Server。凭据通过环境变量或密钥管理系统提供。Engine 参数与驱动 connect_args 分开。

### 3.3 entities

每个实体定义统一字段、字段类型、业务主键，以及 new/old 两套 SQL。SQL 返回列名必须与统一字段名完全一致。允许 SQL 中 JOIN 任意数量的物理表。

统一字段类型：string、integer、decimal、float、boolean、date、datetime、time、json、binary。金额和精确数量使用 Decimal，不使用 float。

主键要求：
- 单字段或复合字段。
- 不允许 NULL。
- 每侧唯一。
- 抽取结果必须按统一比较顺序递增。
- 不同数据库 collation 不一致时，不可直接假设排序一致；必要时使用本地外部排序。

### 3.4 compare

默认规则与字段级覆盖规则分离。支持 NULL/空字符串策略、首尾空格、大小写、Decimal 精度和容差、日期时间精度与时区。规范化仅用于比较，不得覆盖快照原始值。

### 3.5 write

统一字段可映射到一个或多个物理表列。每个 target 定义物理表、列、统一主键到物理键的映射、预期影响行数。不可写字段禁止生成 SQL。目标必须能被完整主键唯一定位。

## 4. 配置加载与校验

使用 PyYAML 读取 YAML，Pydantic v2 做单文件结构校验，ConfigValidator 做跨文件校验：
- 项目引用连接必须存在。
- 每个实体必须有同名 compare/write 配置。
- compare/write 引用字段必须存在。
- 抽取连接必须存在。
- 写入 target 的键映射必须覆盖全部统一主键。
- 未知配置字段禁止静默忽略。
- 配置加载不自动连接数据库；连接测试独立执行。
- 每个任务保存配置快照及 SHA-256；密码等秘密脱敏或不进入快照。

## 5. 数据库连接与抽取

SQLAlchemy Core 管理 Engine 和 Connection，不使用 ORM。
- Engine 在项目运行期间按连接 ID 复用。
- 每次抽取单独取得 Connection，抽取结束关闭。
- QueryExecutor 使用迭代方式 fetchmany，不使用 fetchall。
- `stream_results` 是流式请求，不保证每种驱动都启用服务端游标；MySQL、Oracle、SQL Server 等必须针对实际驱动做集成验证。
- 抽取 SQL 使用参数绑定，不把用户输入直接拼接进 SQL。
- 执行结果列名与实体字段集合严格一致。
- RecordMapper 将驱动值映射为统一类型；不在抽取阶段 trim、舍入或改写业务值。
- 主键验证器检查 NULL、重复和顺序。
- 任意一条记录结构或类型错误，整个快照失败，不静默跳过。

## 6. 快照

每个任务、实体、来源保存独立 JSONL 快照。每行一条统一记录。Decimal/date/datetime/time/binary 使用带类型标记的编码，必须支持往返解码。原始 JSON 对象需避免与序列化器保留标记冲突。

快照先写临时文件，成功后原子重命名。记录数量、开始/结束时间、连接 ID、SHA-256 写入 manifest。失败文件不得被标记为完整快照。

建议目录：

```text
workspace/<task-id>/
  config/
  snapshots/
  reports/
  decisions/
  sql/
```

## 7. 数据一致性

两边抽取时间不同可能产生假差异。支持策略：
- NONE：仅记录时间，不保证跨库业务时间一致。
- BUSINESS_TIME：两侧按共同业务截止时间查询；必须覆盖 JOIN 相关表或使用历史版本。
- DATABASE_SNAPSHOT：单库事务快照；新旧数据库的快照通常无法天然代表同一个业务时间点。

不能把两个数据库分别开启一致性事务等同于跨库同一时刻。高风险迁移应使用业务冻结窗口、历史版本或共同截止点。

## 8. 比对引擎（待实现）

输入为两份有序快照。使用双路归并：
- new_key == old_key：逐字段比较。
- new_key < old_key：NEW_ONLY。
- new_key > old_key：OLD_ONLY。
时间复杂度 O(N+M)，额外内存主要为当前记录和缓冲。
字段差异类型 VALUE_DIFF；记录差异类型 NEW_ONLY、OLD_ONLY。复合主键按定义顺序比较。字符串排序必须有明确统一规则。

规范化规则按字段类型执行。规范化值不写回快照。每个差异关联原始值、业务主键、字段名、任务 ID 和原值指纹。

## 9. SQLite 元数据存储（待实现）

建议表：
- recon_project
- recon_entity
- recon_task
- recon_task_artifact
- recon_difference
- recon_decision
- recon_sql_generation

差异和决策分批写入，建立 task_id、entity_id、business_key、difference_id 等索引。JSONL 保存大体量原始快照，SQLite 保存索引和元数据。

## 10. Excel 决策工作流（待实现）

建议 Sheet：
- 差异明细：一行一个字段差异。
- 记录级差异：NEW_ONLY / OLD_ONLY。
- 统计汇总。
- 使用说明。

决策：
- NEW：以新库为准，更新旧库。
- OLD：以旧库为准，更新新库。
- MANUAL：人工值更新两边。
- IGNORE：不生成 SQL。

导入时只信任 difference_id、decision、manual_value、reason 等决策列。Excel 中的原始新旧值仅供阅读，不作为 SQL 输入。导入必须校验任务批次、差异 ID、重复决策、字段类型和决策合法性。

空单元格表示未填写；特殊标记 `#NULL` 表示显式 NULL；空字符串必须有明确编码约定，避免 Excel 自动将其变成空单元格。

## 11. SQL 生成（待实现）

先将决策转成内部 Statement，不从 Excel 直接拼接 SQL。UPDATE 应包含：
- SET 新值。
- WHERE 完整业务键映射。
- WHERE 原值保护条件（NULL 使用 IS NULL 或方言等价表达式）。
- expected_rows 预期影响行数。

同一表、相同键和兼容原值条件的字段可合并；合并前必须确认条件兼容。多表写入按配置顺序生成。不同数据库分别输出脚本，不做跨库事务。

生成物：
- SQL 文件。
- manifest（目标数据库、配置版本、任务 ID、语句数、预期行数、哈希）。
- README（执行顺序、备份、事务、回滚和行数核对说明）。

严格执行脚本应检查实际影响行数并在不符合预期时回滚；普通 UPDATE 事务本身不会自动识别零行更新。具体脚本实现需按数据库方言验证。

## 12. 验证与闭环（待实现）

工具不执行生成 SQL，因此不能将生成状态标记为已验证。人工执行后创建新验证任务，重新抽取并比对。新任务关联原任务，生成验证报告。状态可包括 CREATED、VALIDATED、EXTRACTING、EXTRACTED、COMPARING、COMPARED、EXPORTED、DECIDED、GENERATED、FAILED、CONFLICT、PARTIAL、CANCELLED。

## 13. 安全与审计

- 连接凭据不写入普通日志和配置快照。
- SQL 标识符只来自受控配置，不接受 Excel 提供表名/列名。
- SQL 值必须由方言安全格式化或参数化。
- 生成脚本包含原值保护条件。
- 生成前校验配置版本、快照哈希、差异 ID 和决策完整性。
- 不自动执行 SQL。
- 对快照、决策文件和生成物计算哈希，保留审计信息。

## 14. 性能目标

目标数据量为数万到数十万条。避免全量加载到 Python List/DataFrame。数据库读取采用批量流式；快照采用 JSONL；差异/决策分批写 SQLite；Excel 使用 openpyxl read_only/write_only。Excel 单 Sheet 建议控制在约 50 万行以内，超出拆分或使用 CSV。

## 15. 技术选型

| 领域 | 技术 |
|---|---|
| 语言 | Python 3.12+ |
| CLI | Typer |
| 配置 | PyYAML + Pydantic v2 |
| 数据库 | SQLAlchemy Core |
| 快照 | JSONL |
| 元数据 | SQLite |
| Excel | openpyxl |
| 日志 | Loguru |
| 测试 | pytest |
| 依赖 | uv |

## 16. 当前代码实现范围

当前交付仓库已包含：
- Pydantic 配置模型。
- YAML 配置加载和环境变量替换。
- 项目级配置组装。
- 基础跨文件引用校验。
- SQLAlchemy Engine 工厂。
- 基础流式查询执行器。
- 统一字段映射和类型检查。
- 主键非空、唯一、递增校验。
- JSONL 类型序列化、读取、原子写入和 SHA-256。
- `validate`、`test-connection`、`extract` CLI 命令。
- 少量单元测试及示例配置。

这些代码是第一阶段可运行骨架，尚未在真实 PostgreSQL/MySQL 环境做端到端认证。驱动级流式游标、连接 URL 方言组合、时区语义、并发任务和大数据性能需要集成测试。

## 17. 后续实现计划

见同目录 `implementation-plan.md`。计划按配置、抽取、比对、存储、Excel、SQL、验证、发布分阶段推进。

## 追加实现：M2 双路归并比对（当前代码）

新增 `src/recon/compare/`：

- `CompareNormalizer`：按实体字段类型和 compare YAML 执行字符串去空格/大小写、Decimal scale+tolerance、datetime 时区与精度、NULL/空串规则。
- `CompareEngine`：以两份已排序 JSONL 快照为输入，双指针归并，时间复杂度 O(N+M)，只保留当前两条记录在内存；输出差异 JSONL，使用临时文件写入并原子替换。
- 差异类型：`VALUE_DIFF`、`NEW_ONLY`、`OLD_ONLY`。记录级差异的 `field_name` 为 null；仅新库存在的记录放在 `new_value`，仅旧库存在的记录放在 `old_value`。
- `difference_id`：对 entity、业务主键、字段和差异类型做规范 JSON 后 SHA-256 截断，因而同一实体/主键/字段/类型在重复运行中 ID 稳定。它不是数据内容指纹；数据内容指纹后续用于决策导入时校验原值是否变化。
- CLI：`recon compare --entity employee --new-snapshot ... --old-snapshot ... [--config ./config] [--output ...]`。

重要约束与当前边界：

1. 输入快照必须按业务主键严格升序，且主键唯一；引擎会在运行中检测重复或乱序并失败，不会静默产生错误结果。
2. 两侧业务主键必须可直接比较，复合主键按 tuple 字典序比较。数据库排序规则、大小写排序、NULL 排序与 Python 比较可能不同；抽取 SQL 应显式按统一主键排序，并保证键类型与排序语义一致。跨库 collation 不一致时，应在 SQL 中使用一致的排序表达式，或后续启用外部排序模块。
3. 当前比较结果落 JSONL，不是 SQLite。SQLite 任务/差异/决策仓储仍待实现。
4. Decimal 当前先按 scale 四舍五入，再比较舍入后差值是否不超过 tolerance。业务上如需“原始值差值容差”而非“舍入后差值容差”，应调整规则定义并补充测试。
5. datetime 对无时区值按配置时区解释；有时区值转换到配置时区。源数据库字段若实际存储的是 UTC 但返回 naive datetime，必须在抽取层明确其语义。
6. 目前 `difference_id` 不含 new/old 值；这保证同一差异定位稳定，但无法用于判断差异原值是否被修改。后续 Decision 导入必须增加 `value_fingerprint`。
