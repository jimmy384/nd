from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class UnifiedRecord:
    entity_id: str
    business_key: tuple[Any, ...]
    values: dict[str, Any]
