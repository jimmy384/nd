from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from typing import Any
from recon.model import UnifiedRecord

class RecordMapper:
    def __init__(self, entity):
        self.entity = entity

    def map_record(self, row: dict[str, Any]) -> UnifiedRecord:
        expected, actual = set(self.entity.fields), set(row)
        if expected != actual:
            raise ValueError(
                f"SQL result columns mismatch; missing={sorted(expected-actual)}, "
                f"extra={sorted(actual-expected)}"
            )
        values = {}
        for name, field in self.entity.fields.items():
            value = row[name]
            if value is None:
                if not field.nullable:
                    raise ValueError(f"Non-null field returned NULL: {name}")
                values[name] = None
            else:
                values[name] = self._convert(value, field.type, name)
        key = tuple(values[name] for name in self.entity.keys)
        if any(part is None for part in key):
            raise ValueError(f"Business key contains NULL: {key}")
        return UnifiedRecord(self.entity.id, key, values)

    @staticmethod
    def _convert(value, field_type: str, field_name: str):
        if field_type == "string":
            if not isinstance(value, str): raise TypeError(f"{field_name}: expected string")
            return value
        if field_type == "integer":
            if isinstance(value, bool) or not isinstance(value, int):
                raise TypeError(f"{field_name}: expected integer")
            return value
        if field_type == "decimal":
            if isinstance(value, (bool, float)):
                raise TypeError(f"{field_name}: float/bool is not accepted as decimal")
            try: return value if isinstance(value, Decimal) else Decimal(value)
            except (InvalidOperation, TypeError, ValueError) as exc:
                raise TypeError(f"{field_name}: invalid decimal") from exc
        if field_type == "float":
            if isinstance(value, bool): raise TypeError(f"{field_name}: expected float")
            return float(value)
        if field_type == "boolean":
            if not isinstance(value, bool): raise TypeError(f"{field_name}: expected boolean")
            return value
        if field_type == "date":
            if isinstance(value, datetime) or not isinstance(value, date):
                raise TypeError(f"{field_name}: expected date")
            return value
        if field_type == "datetime":
            if not isinstance(value, datetime): raise TypeError(f"{field_name}: expected datetime")
            return value
        if field_type == "time":
            if not isinstance(value, time): raise TypeError(f"{field_name}: expected time")
            return value
        if field_type == "json":
            if not isinstance(value, (dict, list)): raise TypeError(f"{field_name}: expected object/array")
            return value
        if field_type == "binary":
            if not isinstance(value, (bytes, bytearray, memoryview)):
                raise TypeError(f"{field_name}: expected bytes")
            return bytes(value)
        raise ValueError(f"Unsupported field type: {field_type}")
