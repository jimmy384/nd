from collections.abc import Iterator
from typing import Any
from sqlalchemy import text
from sqlalchemy.engine import Engine

class QueryExecutor:
    def execute(
        self,
        engine: Engine,
        sql: str,
        parameters: dict[str, Any] | None = None,
        fetch_size: int = 1000,
    ) -> Iterator[dict[str, Any]]:
        # Connection remains open for the full generator iteration.
        with engine.connect() as connection:
            streaming_connection = connection.execution_options(
                stream_results=True,
                max_row_buffer=fetch_size,
            )
            result = streaming_connection.execute(text(sql), parameters or {})
            try:
                while True:
                    rows = result.fetchmany(fetch_size)
                    if not rows:
                        break
                    for row in rows:
                        yield dict(row._mapping)
            finally:
                result.close()
