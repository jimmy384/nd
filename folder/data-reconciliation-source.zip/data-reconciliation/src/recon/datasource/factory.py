from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.engine import URL
from recon.config.models import ConnectionConfig

class ConnectionFactory:
    def __init__(self):
        self._engines: dict[str, Engine] = {}

    def get_engine(self, connection_id: str, config: ConnectionConfig) -> Engine:
        if connection_id not in self._engines:
            self._engines[connection_id] = self._create_engine(config)
        return self._engines[connection_id]

    def _create_engine(self, config: ConnectionConfig) -> Engine:
        if config.url:
            url = config.url
        else:
            url = URL.create(
                drivername=f"{config.dialect}+{config.driver}",
                username=config.username,
                password=config.password,
                host=config.host,
                port=config.port,
                database=config.database,
            )
        return create_engine(
            url,
            connect_args=config.connect_args,
            **config.engine_options,
        )

    def dispose(self):
        for engine in self._engines.values():
            engine.dispose()
        self._engines.clear()
