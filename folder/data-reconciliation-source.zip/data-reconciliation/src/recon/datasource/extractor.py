from pathlib import Path
from datetime import datetime, timezone
from recon.datasource.mapper import RecordMapper
from recon.datasource.keys import KeyValidator
from recon.datasource.executor import QueryExecutor
from recon.snapshot.writer import SnapshotWriter

class Extractor:
    def __init__(self, connection_factory, query_executor=None, snapshot_writer=None):
        self.connection_factory = connection_factory
        self.query_executor = query_executor or QueryExecutor()
        self.snapshot_writer = snapshot_writer or SnapshotWriter()

    def extract(self, entity, side, connections, output_path: Path, default_fetch_size=1000):
        if side not in ("new", "old"):
            raise ValueError("side must be 'new' or 'old'")
        extract = entity.extract[side]
        connection_config = connections[extract.connection]
        engine = self.connection_factory.get_engine(extract.connection, connection_config)
        mapper = RecordMapper(entity)
        key_validator = KeyValidator()
        fetch_size = extract.fetch_size or default_fetch_size

        def records():
            rows = self.query_executor.execute(
                engine=engine,
                sql=extract.sql,
                parameters=extract.parameters,
                fetch_size=fetch_size,
            )
            for row in rows:
                record = mapper.map_record(row)
                key_validator.validate(record.business_key)
                yield record

        started_at = datetime.now(timezone.utc).isoformat()
        result = self.snapshot_writer.write(output_path, records())
        result.update({
            "entity_id": entity.id,
            "side": side,
            "connection_id": extract.connection,
            "started_at": started_at,
            "finished_at": datetime.now(timezone.utc).isoformat(),
        })
        return result
