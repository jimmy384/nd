from typing import Any

class KeyValidator:
    """Validates uniqueness and monotonic order for comparable normalized keys."""
    def __init__(self):
        self.previous_key: tuple[Any, ...] | None = None

    def validate(self, key: tuple[Any, ...]) -> None:
        if any(value is None for value in key):
            raise ValueError(f"Business key contains NULL: {key}")
        if self.previous_key is not None:
            try:
                if key == self.previous_key:
                    raise ValueError(f"Duplicate business key: {key}")
                if key < self.previous_key:
                    raise ValueError(
                        f"Extract result is not ordered: {self.previous_key} -> {key}"
                    )
            except TypeError as exc:
                raise ValueError(
                    "Business key values are not mutually orderable; "
                    "use a compatible key type or external sort"
                ) from exc
        self.previous_key = key
