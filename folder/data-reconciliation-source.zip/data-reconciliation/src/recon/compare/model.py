from dataclasses import dataclass
from enum import StrEnum
from typing import Any

class DifferenceType(StrEnum):
    VALUE_DIFF = "VALUE_DIFF"
    NEW_ONLY = "NEW_ONLY"
    OLD_ONLY = "OLD_ONLY"

@dataclass(frozen=True)
class Difference:
    difference_id: str
    entity_id: str
    business_key: tuple[Any, ...]
    field_name: str | None
    difference_type: DifferenceType
    new_value: Any = None
    old_value: Any = None

@dataclass(frozen=True)
class CompareResult:
    entity_id: str
    new_count: int
    old_count: int
    difference_count: int
    value_diff_count: int
    new_only_count: int
    old_only_count: int
    differences_path: str
