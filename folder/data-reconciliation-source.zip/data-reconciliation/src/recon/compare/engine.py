import hashlib
import json
import os
from pathlib import Path
from typing import Any, Iterable, Iterator

from recon.config.models import CompareDefinition, EntityDefinition
from recon.model import UnifiedRecord
from recon.snapshot.serializer import SnapshotSerializer
from recon.snapshot.writer import SnapshotReader
from .model import CompareResult, Difference, DifferenceType
from .normalizer import CompareNormalizer

class CompareEngine:
    """Streaming O(N+M) merge comparison. Inputs must be sorted by business_key."""
    def __init__(self, entity: EntityDefinition, config: CompareDefinition):
        self.entity = entity
        self.normalizer = CompareNormalizer(entity, config)

    def compare(self, new_records: Iterable[UnifiedRecord],
                old_records: Iterable[UnifiedRecord], output: Path) -> CompareResult:
        output.parent.mkdir(parents=True, exist_ok=True)
        temp = output.with_suffix(output.suffix + ".tmp")
        new_count = old_count = value_count = new_only = old_only = total = 0
        new_iter, old_iter = iter(new_records), iter(old_records)
        new_item, old_item = self._next_checked(new_iter, "new"), self._next_checked(old_iter, "old")
        prev_new = prev_old = None
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                while new_item is not None or old_item is not None:
                    if new_item is None:
                        old_count += 1
                        differences = [self._record_difference(old_item, DifferenceType.OLD_ONLY)]
                        old_item = self._advance(old_iter, old_item, prev_old, "old")
                        prev_old = differences[0].business_key
                        old_only += 1
                    elif old_item is None:
                        new_count += 1
                        differences = [self._record_difference(new_item, DifferenceType.NEW_ONLY)]
                        new_item = self._advance(new_iter, new_item, prev_new, "new")
                        prev_new = differences[0].business_key
                        new_only += 1
                    else:
                        comparison = self._compare_keys(new_item.business_key, old_item.business_key)
                        if comparison < 0:
                            new_count += 1
                            differences = [self._record_difference(new_item, DifferenceType.NEW_ONLY)]
                            new_item = self._advance(new_iter, new_item, prev_new, "new")
                            prev_new = differences[0].business_key
                            new_only += 1
                        elif comparison > 0:
                            old_count += 1
                            differences = [self._record_difference(old_item, DifferenceType.OLD_ONLY)]
                            old_item = self._advance(old_iter, old_item, prev_old, "old")
                            prev_old = differences[0].business_key
                            old_only += 1
                        else:
                            new_count += 1
                            old_count += 1
                            differences = self._compare_values(new_item, old_item)
                            prev_new, prev_old = new_item.business_key, old_item.business_key
                            new_item = self._next_checked(new_iter, "new")
                            old_item = self._next_checked(old_iter, "old")
                            if new_item is not None and self._compare_keys(prev_new, new_item.business_key) >= 0:
                                raise ValueError("new snapshot keys are duplicated or not strictly sorted")
                            if old_item is not None and self._compare_keys(prev_old, old_item.business_key) >= 0:
                                raise ValueError("old snapshot keys are duplicated or not strictly sorted")
                    for difference in differences:
                        stream.write(json.dumps(SnapshotSerializer.encode_value({
                            "difference_id": difference.difference_id,
                            "entity_id": difference.entity_id,
                            "business_key": list(difference.business_key),
                            "field_name": difference.field_name,
                            "difference_type": difference.difference_type.value,
                            "new_value": difference.new_value,
                            "old_value": difference.old_value,
                        }), ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
                        total += 1
                        if difference.difference_type == DifferenceType.VALUE_DIFF:
                            value_count += 1
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, output)
        except Exception:
            temp.unlink(missing_ok=True)
            raise
        return CompareResult(self.entity.id, new_count, old_count, total, value_count,
                             new_only, old_only, str(output))

    def _compare_values(self, new: UnifiedRecord, old: UnifiedRecord) -> list[Difference]:
        result = []
        for field_name in self.entity.fields:
            a, b = new.values.get(field_name), old.values.get(field_name)
            if not self.normalizer.equal(field_name, a, b):
                result.append(self._difference(new.business_key, field_name,
                                               DifferenceType.VALUE_DIFF, a, b))
        return result

    def _record_difference(self, record: UnifiedRecord, kind: DifferenceType) -> Difference:
        return self._difference(record.business_key, None, kind,
                                record.values if kind == DifferenceType.NEW_ONLY else None,
                                record.values if kind == DifferenceType.OLD_ONLY else None)

    def _difference(self, key: tuple[Any, ...], field: str | None, kind: DifferenceType,
                    new_value: Any, old_value: Any) -> Difference:
        identity = {"entity": self.entity.id, "key": SnapshotSerializer.encode_value(list(key)),
                    "field": field, "type": kind.value}
        canonical = json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        difference_id = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:24]
        return Difference(difference_id, self.entity.id, key, field, kind, new_value, old_value)

    def _next_checked(self, iterator: Iterator[UnifiedRecord], side: str):
        try:
            item = next(iterator)
        except StopIteration:
            return None
        if not isinstance(item, UnifiedRecord):
            raise TypeError(f"{side} snapshot yielded non-UnifiedRecord")
        if item.entity_id != self.entity.id:
            raise ValueError(f"{side} snapshot entity mismatch: {item.entity_id!r}")
        if len(item.business_key) != len(self.entity.keys):
            raise ValueError(f"{side} snapshot business key arity mismatch")
        missing = set(self.entity.fields) - set(item.values)
        extra = set(item.values) - set(self.entity.fields)
        if missing or extra:
            raise ValueError(f"{side} snapshot field mismatch; missing={sorted(missing)}, extra={sorted(extra)}")
        for index, key_name in enumerate(self.entity.keys):
            if item.values[key_name] != item.business_key[index]:
                raise ValueError(f"{side} snapshot key field {key_name!r} does not match business_key")
        return item

    def _advance(self, iterator, current, previous, side):
        next_item = self._next_checked(iterator, side)
        if next_item is not None and self._compare_keys(current.business_key, next_item.business_key) >= 0:
            raise ValueError(f"{side} snapshot keys are duplicated or not strictly sorted")
        return next_item

    @staticmethod
    def _compare_keys(left: tuple[Any, ...], right: tuple[Any, ...]) -> int:
        if len(left) != len(right):
            raise ValueError("business key arity mismatch")
        try:
            return (left > right) - (left < right)
        except TypeError as exc:
            raise TypeError(f"business keys are not mutually orderable: {left!r}, {right!r}") from exc

def read_differences(path: Path):
    with path.open("r", encoding="utf-8") as stream:
        for line_no, line in enumerate(stream, 1):
            try:
                yield SnapshotSerializer.decode_value(json.loads(line))
            except Exception as exc:
                raise ValueError(f"Invalid difference file at line {line_no}: {exc}") from exc
