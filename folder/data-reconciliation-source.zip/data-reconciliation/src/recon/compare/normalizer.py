from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any
from zoneinfo import ZoneInfo

from recon.config.models import CompareDefinition, EntityDefinition

class CompareNormalizer:
    def __init__(self, entity: EntityDefinition, config: CompareDefinition):
        self.entity = entity
        self.config = config

    def equal(self, field_name: str, left: Any, right: Any) -> bool:
        rule = self.config.fields.get(field_name)
        default = self.config.default
        if left is None or right is None:
            if default.null_equals_empty:
                if left in (None, "") and right in (None, ""):
                    return True
            return left is right

        field = self.entity.fields[field_name]
        if field.type == "string":
            trim = (rule.ignore_leading_trailing_spaces
                    if rule and rule.ignore_leading_trailing_spaces is not None
                    else default.ignore_leading_trailing_spaces)
            case_sensitive = (rule.case_sensitive if rule and rule.case_sensitive is not None
                              else default.case_sensitive)
            a, b = str(left), str(right)
            if trim:
                a, b = a.strip(), b.strip()
            if not case_sensitive:
                a, b = a.casefold(), b.casefold()
            return a == b

        if field.type == "decimal":
            decimal_rule = rule.decimal if rule and rule.decimal else None
            scale = decimal_rule.scale if decimal_rule else 2
            tolerance = Decimal(decimal_rule.tolerance if decimal_rule else "0")
            try:
                a, b = Decimal(str(left)), Decimal(str(right))
            except (InvalidOperation, ValueError):
                return left == right
            quantum = Decimal(1).scaleb(-scale)
            a = a.quantize(quantum, rounding=ROUND_HALF_UP)
            b = b.quantize(quantum, rounding=ROUND_HALF_UP)
            return abs(a - b) <= tolerance

        if field.type == "datetime" and isinstance(left, datetime) and isinstance(right, datetime):
            dt_rule = rule.datetime if rule and rule.datetime else None
            precision = dt_rule.precision if dt_rule else "second"
            tz_name = dt_rule.timezone if dt_rule else "Asia/Shanghai"
            a, b = self._datetime(left, tz_name), self._datetime(right, tz_name)
            if precision == "day":
                return a.date() == b.date()
            if precision == "second":
                return a.replace(microsecond=0) == b.replace(microsecond=0)
            if precision == "millisecond":
                return a.replace(microsecond=(a.microsecond // 1000) * 1000) == b.replace(
                    microsecond=(b.microsecond // 1000) * 1000)
            return a == b

        return left == right

    @staticmethod
    def _datetime(value: datetime, timezone_name: str) -> datetime:
        target = ZoneInfo(timezone_name)
        if value.tzinfo is None:
            return value.replace(tzinfo=target)
        return value.astimezone(target)
