from pathlib import Path
import typer
from sqlalchemy import text
from recon.config import ConfigManager
from recon.datasource.factory import ConnectionFactory
from recon.datasource.extractor import Extractor

app = typer.Typer(no_args_is_help=True)

@app.command()
def validate(config: Path = typer.Option(Path("./config"), "--config")):
    try:
        project = ConfigManager.load(config)
        typer.echo(f"Configuration valid: {project.project.project.name}")
    except Exception as exc:
        typer.echo(f"Configuration invalid: {exc}", err=True)
        raise typer.Exit(1)

@app.command("test-connection")
def test_connection(config: Path = typer.Option(Path("./config"), "--config")):
    project = ConfigManager.load(config)
    factory = ConnectionFactory()
    try:
        for side in ("new", "old"):
            connection_id = getattr(project.project.project.sources, side)
            engine = factory.get_engine(connection_id, project.connections.connections[connection_id])
            with engine.connect() as connection:
                connection.execute(text("SELECT 1"))
            typer.echo(f"{side}: connection OK ({connection_id})")
    finally:
        factory.dispose()

@app.command()
def extract(
    entity: str = typer.Option(..., "--entity"),
    side: str = typer.Option(..., "--side"),
    config: Path = typer.Option(Path("./config"), "--config"),
    output: Path | None = typer.Option(None, "--output"),
):
    project = ConfigManager.load(config)
    if entity not in project.entities:
        raise typer.BadParameter(f"Unknown entity: {entity}")
    entity_def = project.entities[entity].entity
    workspace = Path(project.project.project.workspace)
    if not workspace.is_absolute():
        workspace = project.root / workspace
    output_path = output or (workspace / "extracts" / entity / f"{side}.jsonl")
    factory = ConnectionFactory()
    try:
        extractor = Extractor(factory)
        result = extractor.extract(
            entity_def,
            side,
            project.connections.connections,
            output_path,
            project.project.project.defaults.fetch_size,
        )
        typer.echo(
            f"Extracted {result['record_count']} records to {result['path']} "
            f"(sha256={result['sha256']})"
        )
    except Exception as exc:
        typer.echo(f"Extraction failed: {exc}", err=True)
        raise typer.Exit(1)
    finally:
        factory.dispose()

if __name__ == "__main__":
    app()
