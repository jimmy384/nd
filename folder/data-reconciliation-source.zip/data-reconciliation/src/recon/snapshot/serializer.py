import base64
from datetime import date, datetime, time
from decimal import Decimal
from typing import Any

class SnapshotSerializer:
    @classmethod
    def encode_value(cls, value: Any):
        if value is None or isinstance(value, (str, int, bool)):
            return value
        if isinstance(value, Decimal):
            return {"$recon_type": "decimal", "value": str(value)}
        if isinstance(value, datetime):
            return {"$recon_type": "datetime", "value": value.isoformat()}
        if isinstance(value, date):
            return {"$recon_type": "date", "value": value.isoformat()}
        if isinstance(value, time):
            return {"$recon_type": "time", "value": value.isoformat()}
        if isinstance(value, (bytes, bytearray, memoryview)):
            return {"$recon_type": "binary", "value": base64.b64encode(bytes(value)).decode("ascii")}
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                raise ValueError("NaN and Infinity are not supported in JSON snapshots")
            return value
        if isinstance(value, list):
            return [cls.encode_value(x) for x in value]
        if isinstance(value, dict):
            # Escape user objects that happen to use our reserved discriminator.
            if "$recon_type" in value:
                return {"$recon_type": "object", "value": {
                    str(k): cls.encode_value(v) for k, v in value.items()
                }}
            return {str(k): cls.encode_value(v) for k, v in value.items()}
        raise TypeError(f"Unsupported snapshot type: {type(value)!r}")

    @classmethod
    def decode_value(cls, value):
        if isinstance(value, list):
            return [cls.decode_value(x) for x in value]
        if isinstance(value, dict):
            kind = value.get("$recon_type")
            raw = value.get("value")
            if kind == "decimal": return Decimal(raw)
            if kind == "datetime": return datetime.fromisoformat(raw)
            if kind == "date": return date.fromisoformat(raw)
            if kind == "time": return time.fromisoformat(raw)
            if kind == "binary": return base64.b64decode(raw)
            if kind == "object":
                return {k: cls.decode_value(v) for k, v in raw.items()}
            return {k: cls.decode_value(v) for k, v in value.items()}
        return value
