import hashlib
import json
import os
from pathlib import Path
from collections.abc import Iterable
from recon.model import UnifiedRecord
from .serializer import SnapshotSerializer

class SnapshotWriter:
    def write(self, path: Path, records: Iterable[UnifiedRecord]) -> dict:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix(path.suffix + ".tmp")
        count = 0
        try:
            with temp_path.open("w", encoding="utf-8", newline="\n") as stream:
                for record in records:
                    payload = {
                        "entity_id": record.entity_id,
                        "business_key": record.business_key,
                        "values": record.values,
                    }
                    encoded = SnapshotSerializer.encode_value(payload)
                    stream.write(json.dumps(encoded, ensure_ascii=False, separators=(",", ":"), allow_nan=False))
                    stream.write("\n")
                    count += 1
                stream.flush()
                os.fsync(stream.fileno())
            digest = hashlib.sha256()
            with temp_path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
            os.replace(temp_path, path)
            return {"path": str(path), "record_count": count, "sha256": digest.hexdigest()}
        except Exception:
            temp_path.unlink(missing_ok=True)
            raise

class SnapshotReader:
    def read(self, path: Path):
        from recon.model import UnifiedRecord
        with path.open("r", encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    item = SnapshotSerializer.decode_value(json.loads(line))
                    yield UnifiedRecord(
                        entity_id=item["entity_id"],
                        business_key=tuple(item["business_key"]),
                        values=item["values"],
                    )
                except Exception as exc:
                    raise ValueError(f"Invalid snapshot at line {line_number}: {exc}") from exc
