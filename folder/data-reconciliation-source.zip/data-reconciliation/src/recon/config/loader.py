import os
import re
from pathlib import Path
from typing import TypeVar
import yaml
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)
ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-(.*?))?\}")

class ConfigLoader:
    @staticmethod
    def resolve_env(value: str) -> str:
        def replace(match: re.Match) -> str:
            name, default = match.group(1), match.group(2)
            result = os.environ.get(name)
            if result is not None:
                return result
            if default is not None:
                return default
            raise ValueError(f"Missing environment variable: {name}")
        return ENV_PATTERN.sub(replace, value)

    @classmethod
    def resolve_env_recursive(cls, value):
        if isinstance(value, str):
            return cls.resolve_env(value)
        if isinstance(value, list):
            return [cls.resolve_env_recursive(x) for x in value]
        if isinstance(value, dict):
            return {k: cls.resolve_env_recursive(v) for k, v in value.items()}
        return value

    @classmethod
    def load(cls, path: Path, model_type: type[T]) -> T:
        with path.open("r", encoding="utf-8") as stream:
            raw = yaml.safe_load(stream) or {}
        raw = cls.resolve_env_recursive(raw)
        return model_type.model_validate(raw)
