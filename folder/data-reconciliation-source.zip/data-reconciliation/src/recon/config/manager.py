from pathlib import Path
from .loader import ConfigLoader
from .models import ProjectFile, ConnectionsFile, EntityFile, CompareFile, WriteFile
from .validator import ConfigValidator

class ProjectConfig:
    def __init__(self, project, connections, entities, compares, writes, root: Path):
        self.project = project
        self.connections = connections
        self.entities = entities
        self.compares = compares
        self.writes = writes
        self.root = root

class ConfigManager:
    @classmethod
    def load(cls, root: str | Path) -> ProjectConfig:
        root = Path(root).resolve()
        project = ConfigLoader.load(root / "project.yaml", ProjectFile)
        connections = ConfigLoader.load(root / "connections.yaml", ConnectionsFile)
        entities, compares, writes = {}, {}, {}

        for path in sorted((root / "entities").glob("*.yaml")):
            item = ConfigLoader.load(path, EntityFile)
            entity_id = item.entity.id
            if entity_id in entities:
                raise ValueError(f"Duplicate entity id: {entity_id}")
            if path.stem != entity_id:
                raise ValueError(f"{path.name}: filename must match entity id '{entity_id}'")
            entities[entity_id] = item

        for directory, model, target in (
            ("compare", CompareFile, compares),
            ("write", WriteFile, writes),
        ):
            for path in sorted((root / directory).glob("*.yaml")):
                item = ConfigLoader.load(path, model)
                if path.stem in target:
                    raise ValueError(f"Duplicate config: {path}")
                target[path.stem] = item

        config = ProjectConfig(project, connections, entities, compares, writes, root)
        ConfigValidator().validate(config)
        return config
