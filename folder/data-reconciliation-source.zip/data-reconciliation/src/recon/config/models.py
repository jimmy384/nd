from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class ConfigBase(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class DataSources(ConfigBase):
    new: str
    old: str

class ProjectDefaults(ConfigBase):
    fetch_size: int = Field(default=1000, gt=0)
    batch_size: int = Field(default=5000, gt=0)
    snapshot_format: Literal["jsonl"] = "jsonl"

class ProjectOptions(ConfigBase):
    keep_snapshot: bool = True
    check_duplicate_keys: bool = True
    check_not_null: bool = True

class ProjectInfo(ConfigBase):
    id: str
    name: str
    version: int = Field(ge=1)
    sources: DataSources
    defaults: ProjectDefaults = Field(default_factory=ProjectDefaults)
    options: ProjectOptions = Field(default_factory=ProjectOptions)
    workspace: str = "./workspace"

class ProjectFile(ConfigBase):
    project: ProjectInfo

class ConnectionConfig(ConfigBase):
    dialect: Literal["postgresql", "mysql", "oracle", "mssql"]
    driver: str
    url: str | None = None
    username: str | None = None
    password: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    engine_options: dict[str, Any] = Field(default_factory=dict)
    connect_args: dict[str, Any] = Field(default_factory=dict)

class ConnectionsFile(ConfigBase):
    connections: dict[str, ConnectionConfig]

FieldType = Literal["string", "integer", "decimal", "float", "boolean",
                    "date", "datetime", "time", "json", "binary"]

class EntityField(ConfigBase):
    label: str
    type: FieldType
    nullable: bool = True

class ExtractConfig(ConfigBase):
    connection: str
    sql: str = Field(min_length=1)
    fetch_size: int | None = Field(default=None, gt=0)
    parameters: dict[str, Any] = Field(default_factory=dict)

class EntityDefinition(ConfigBase):
    id: str
    name: str
    description: str = ""
    keys: list[str] = Field(min_length=1)
    fields: dict[str, EntityField]
    extract: dict[str, ExtractConfig]

    @model_validator(mode="after")
    def validate_entity(self):
        if len(self.keys) != len(set(self.keys)):
            raise ValueError("key fields must be unique")
        for key in self.keys:
            if key not in self.fields:
                raise ValueError(f"key field not defined: {key}")
            if self.fields[key].nullable:
                raise ValueError(f"key field cannot be nullable: {key}")
        if set(self.extract) != {"new", "old"}:
            raise ValueError("extract must define exactly 'new' and 'old'")
        return self

class EntityFile(ConfigBase):
    entity: EntityDefinition

class DecimalCompareRule(ConfigBase):
    scale: int = Field(default=2, ge=0, le=18)
    tolerance: str = "0"

class DateTimeCompareRule(ConfigBase):
    precision: Literal["day", "second", "millisecond", "microsecond"] = "second"
    timezone: str = "Asia/Shanghai"

class FieldCompareRule(ConfigBase):
    ignore_leading_trailing_spaces: bool | None = None
    case_sensitive: bool | None = None
    decimal: DecimalCompareRule | None = None
    datetime: DateTimeCompareRule | None = None

class DefaultCompareRule(ConfigBase):
    null_equals_empty: bool = False
    ignore_leading_trailing_spaces: bool = False
    case_sensitive: bool = True

class CompareDefinition(ConfigBase):
    default: DefaultCompareRule = Field(default_factory=DefaultCompareRule)
    fields: dict[str, FieldCompareRule] = Field(default_factory=dict)

class CompareFile(ConfigBase):
    compare: CompareDefinition

class WriteTarget(ConfigBase):
    table: str
    column: str
    keys: dict[str, str]
    expected_rows: int = Field(default=1, ge=1)

class FieldWriteConfig(ConfigBase):
    writable: bool = True
    targets: list[WriteTarget] = Field(default_factory=list)

class SideWriteConfig(ConfigBase):
    dialect: Literal["postgresql", "mysql", "oracle", "mssql"]
    fields: dict[str, FieldWriteConfig]

class WriteDefinition(ConfigBase):
    new: SideWriteConfig
    old: SideWriteConfig

class WriteFile(ConfigBase):
    write: WriteDefinition
