class ConfigValidator:
    def validate(self, config):
        project = config.project.project
        connections = config.connections.connections
        for side in ("new", "old"):
            connection_id = getattr(project.sources, side)
            if connection_id not in connections:
                raise ValueError(f"project.sources.{side}: unknown connection '{connection_id}'")

        entity_ids = set(config.entities)
        if set(config.compares) != entity_ids:
            raise ValueError("compare config files must match entity config files exactly")
        if set(config.writes) != entity_ids:
            raise ValueError("write config files must match entity config files exactly")

        for entity_id, entity_file in config.entities.items():
            entity = entity_file.entity
            for side, extract in entity.extract.items():
                if extract.connection not in connections:
                    raise ValueError(
                        f"{entity_id}.{side}: unknown connection '{extract.connection}'"
                    )
            compare = config.compares[entity_id].compare
            for name in compare.fields:
                if name not in entity.fields:
                    raise ValueError(f"{entity_id}: unknown compare field '{name}'")
            write = config.writes[entity_id].write
            for side in ("new", "old"):
                side_write = getattr(write, side)
                for name, field_config in side_write.fields.items():
                    if name not in entity.fields:
                        raise ValueError(f"{entity_id}: unknown write field '{name}'")
                    if field_config.writable and not field_config.targets:
                        raise ValueError(f"{entity_id}.{side}.{name}: writable field has no targets")
                    for target in field_config.targets:
                        if set(target.keys) != set(entity.keys):
                            raise ValueError(
                                f"{entity_id}.{side}.{name}: target key mapping must cover "
                                f"exactly {entity.keys}"
                            )
