from datetime import date, datetime, time
from decimal import Decimal
from recon.snapshot.serializer import SnapshotSerializer

def test_round_trip_typed_values():
    value = {
        "amount": Decimal("10.20"),
        "date": date(2026, 1, 2),
        "datetime": datetime(2026, 1, 2, 3, 4, 5),
        "time": time(3, 4, 5),
        "nested": {"$recon_type": "business-data", "value": 1},
    }
    assert SnapshotSerializer.decode_value(
        SnapshotSerializer.encode_value(value)
    ) == value
