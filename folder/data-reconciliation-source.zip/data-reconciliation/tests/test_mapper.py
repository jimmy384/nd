from decimal import Decimal
import pytest
from recon.config.models import EntityDefinition
from recon.datasource.mapper import RecordMapper

def make_entity():
    return EntityDefinition.model_validate({
        "id": "e", "name": "E", "keys": ["id"],
        "fields": {
            "id": {"label": "ID", "type": "integer", "nullable": False},
            "amount": {"label": "Amount", "type": "decimal", "nullable": True},
        },
        "extract": {
            "new": {"connection": "x", "sql": "select 1"},
            "old": {"connection": "x", "sql": "select 1"},
        }
    })

def test_maps_decimal():
    record = RecordMapper(make_entity()).map_record({"id": 1, "amount": Decimal("2.30")})
    assert record.business_key == (1,)
    assert record.values["amount"] == Decimal("2.30")

def test_rejects_float_decimal():
    with pytest.raises(TypeError):
        RecordMapper(make_entity()).map_record({"id": 1, "amount": 2.3})
