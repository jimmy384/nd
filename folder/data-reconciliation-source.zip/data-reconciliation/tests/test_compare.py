from decimal import Decimal
from pathlib import Path

import pytest

from recon.compare.engine import CompareEngine, read_differences
from recon.compare.model import DifferenceType
from recon.config.models import (
    CompareDefinition, DefaultCompareRule, DecimalCompareRule, EntityDefinition,
    EntityField, FieldCompareRule,
)
from recon.model import UnifiedRecord


@pytest.fixture
def entity():
    return EntityDefinition(
        id="person", name="Person", keys=["id"],
        fields={
            "id": EntityField(label="ID", type="integer", nullable=False),
            "name": EntityField(label="Name", type="string"),
            "amount": EntityField(label="Amount", type="decimal"),
        },
        extract={
            "new": {"connection": "db1", "sql": "select 1"},
            "old": {"connection": "db2", "sql": "select 1"},
        },
    )


def rec(key, name="A", amount=Decimal("1.00")):
    return UnifiedRecord("person", (key,), {"id": key, "name": name, "amount": amount})


def test_merge_compare_and_counts(entity, tmp_path):
    output = tmp_path / "diff.jsonl"
    result = CompareEngine(entity, CompareDefinition()).compare(
        [rec(1), rec(2, "new"), rec(4)],
        [rec(1), rec(3), rec(4, "A", Decimal("2.00"))], output,
    )
    assert (result.new_count, result.old_count) == (3, 3)
    assert result.difference_count == 3
    assert result.new_only_count == 1
    assert result.old_only_count == 1
    rows = list(read_differences(output))
    assert [r["difference_type"] for r in rows] == [
        "NEW_ONLY", "OLD_ONLY", "VALUE_DIFF"
    ]
    assert rows[-1]["field_name"] == "amount"


def test_normalization_rules(entity, tmp_path):
    config = CompareDefinition(
        default=DefaultCompareRule(ignore_leading_trailing_spaces=True),
        fields={"amount": FieldCompareRule(decimal=DecimalCompareRule(scale=2, tolerance="0.02"))},
    )
    result = CompareEngine(entity, config).compare(
        [rec(1, " Alice ", Decimal("1.001"))],
        [rec(1, "Alice", Decimal("1.019"))], tmp_path / "diff.jsonl",
    )
    assert result.difference_count == 0


def test_rejects_duplicate_or_unsorted_keys(entity, tmp_path):
    with pytest.raises(ValueError, match="duplicated or not strictly sorted"):
        CompareEngine(entity, CompareDefinition()).compare(
            [rec(1), rec(1)], [rec(1)], tmp_path / "diff.jsonl"
        )


def test_null_and_empty_are_distinct_by_default(entity, tmp_path):
    left = UnifiedRecord("person", (1,), {"id": 1, "name": None, "amount": Decimal("1")})
    right = UnifiedRecord("person", (1,), {"id": 1, "name": "", "amount": Decimal("1")})
    result = CompareEngine(entity, CompareDefinition()).compare(
        [left], [right], tmp_path / "diff.jsonl"
    )
    assert result.value_diff_count == 1
