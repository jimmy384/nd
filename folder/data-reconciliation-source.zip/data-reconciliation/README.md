# Data Reconciliation

配置驱动的新旧数据库数据比对与校准工具。当前仓库提供配置加载、校验、数据库抽取、统一记录映射和 JSONL 快照的第一阶段实现骨架。

## 安装

```bash
uv sync --extra postgresql --extra mysql --extra dev
uv run recon validate --config ./config
uv run recon test-connection --config ./config
uv run recon extract --config ./config --entity employee --side new
```

连接凭据通过环境变量注入，不要提交真实密码。

## 当前边界

- `validate`：读取 YAML、Pydantic 结构校验、跨文件引用校验。
- `test-connection`：测试项目定义的新旧连接。
- `extract`：执行配置 SQL，映射统一字段，流式写入 JSONL。
- 尚未实现比对、SQLite 任务存储、Excel 决策、SQL 生成、SQL 执行及自动验证。
- 数据库服务端游标行为依驱动而异；本版本提供 SQLAlchemy 流式结果选项，但尚未对所有驱动作集成验证。
